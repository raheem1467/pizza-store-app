enum Category {
    Electronics = "Electronics",
    Clothing = "Clothing",
    Grocery = "Grocery",
}

interface IProduct {
    id: number;
    name: string;
    category: Category;
    price: number;
    stock: number;
}

// Decorator fix
function LogChange(target: any, propertyKey: string, descriptor: PropertyDescriptor) {
    const original = descriptor.value;
    descriptor.value = function(newValue: any) {
        let propName = propertyKey === "setPrice" ? "price" : "stock";
        const oldValue = this[propName];
        console.log(`Product ${this.name} - ${propName} changed from ${oldValue} to ${newValue}`);
        return original.apply(this, [newValue]);
    };
}

class Product implements IProduct {
    constructor(
        public id: number,
        public name: string,
        public category: Category,
        public price: number,
        public stock: number
    ) {}

    @LogChange
    setPrice(newPrice: number) {
        this.price = newPrice;
    }

    @LogChange
    setStock(newStock: number) {
        this.stock = newStock;
    }

    toString(): string {
        return `ID: ${this.id}, Name: ${this.name}, Category: ${this.category}, Price: $${this.price}, Stock: ${this.stock}`;
    }
}

// Array of tuples
const products: [number, Product][] = [
    [1, new Product(1, "Laptop", Category.Electronics, 1200, 10)],
    [2, new Product(2, "Jeans", Category.Clothing, 50, 100)],
    [3, new Product(3, "Apple", Category.Grocery, 1, 500)],
];

console.log("=== Product Inventory ===");
for (const [id, product] of products) console.log(product.toString());

// Trigger updates (decorator logs will now be correct)
products[0][1].setPrice(1100);
products[1][1].setStock(90);

console.log("=== Updated Product Inventory ===");
for (const [id, product] of products) console.log(product.toString());
