var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var Category;
(function (Category) {
    Category["Electronics"] = "Electronics";
    Category["Clothing"] = "Clothing";
    Category["Grocery"] = "Grocery";
})(Category || (Category = {}));
// Decorator fix
function LogChange(target, propertyKey, descriptor) {
    const original = descriptor.value;
    descriptor.value = function (newValue) {
        let propName = propertyKey === "setPrice" ? "price" : "stock";
        const oldValue = this[propName];
        console.log(`Product ${this.name} - ${propName} changed from ${oldValue} to ${newValue}`);
        return original.apply(this, [newValue]);
    };
}
class Product {
    constructor(id, name, category, price, stock) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.stock = stock;
    }
    setPrice(newPrice) {
        this.price = newPrice;
    }
    setStock(newStock) {
        this.stock = newStock;
    }
    toString() {
        return `ID: ${this.id}, Name: ${this.name}, Category: ${this.category}, Price: $${this.price}, Stock: ${this.stock}`;
    }
}
__decorate([
    LogChange
], Product.prototype, "setPrice", null);
__decorate([
    LogChange
], Product.prototype, "setStock", null);
// Array of tuples
const products = [
    [1, new Product(1, "Laptop", Category.Electronics, 1200, 10)],
    [2, new Product(2, "Jeans", Category.Clothing, 50, 100)],
    [3, new Product(3, "Apple", Category.Grocery, 1, 500)],
];
console.log("=== Product Inventory ===");
for (const [id, product] of products)
    console.log(product.toString());
// Trigger updates (decorator logs will now be correct)
products[0][1].setPrice(1100);
products[1][1].setStock(90);
console.log("=== Updated Product Inventory ===");
for (const [id, product] of products)
    console.log(product.toString());
