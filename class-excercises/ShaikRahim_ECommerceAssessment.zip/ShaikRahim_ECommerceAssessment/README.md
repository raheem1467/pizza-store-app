<!-- User Story 1 – Product Showcase Home Page -->

<!--  Overview -->
This project is a Home Page for an E-Commerce Product Portal.
It displays featured products, a category navigation bar, and a newsletter subscription form.

<!--  Features -->
- Semantic HTML5: Uses header, nav, main, section, footer.
- Responsive Layout: Built with Bootstrap grid and Flexbox/Grid for product alignment.
- Product Cards: Displays products with image, name, and price.
- Newsletter Form: Includes validation for user email submission.
- Visual Design: CSS transitions for hover effects and aesthetic alignment.

<!--  How to Run -->
1. Open index.html in a web browser.
2. Navigate through product categories.
3. View featured products and hover over cards for effects.
4. Fill in newsletter form to test validation.


<!--  User Story 2 – Product Listing with API Fetch and Filtering -->

<!--Overview -->
This project is a Product Listing Page built using JavaScript.
It dynamically fetches product data from a mock API (products.json or FakeStoreAPI) 
and allows filtering by category and price.

<!--  Features -->
- Fetch API: Uses async/await to fetch product data.
- Error Handling: Uses try…catch to handle API errors gracefully.
- Dynamic Rendering: Products are displayed dynamically using DOM manipulation.
- Filter & Sort: Users can filter products by category or price.
- Loading Indicator: Shows a “Loading…” message during API calls.


<!--  How to Run -->
1. Open index.html in a browser.
2. Ensure products.json is in the same folder 
3. Interact with the page to filter or sort products dynamically.


<!--  User Story 3 – Product Management Module -->

<!--  Overview -->
This project is a Product Management Module built using TypeScript.
It models and tracks product inventory, allowing price and stock updates 
with decorator-based logging.

<!--Features -->
- Interface & Class: IProduct interface and Product class.
- Enums: Category enum for product categories.
- Decorator: Logs changes to price or stock when updated.
- Data Storage: Products stored in an array of tuples [id, Product].
- Iteration: Uses for…of loops to display inventory.
- Compilation: Successfully compiles to JavaScript and runs with Node.js.

<!--  How to Run -->
1. Open terminal in project folder.
2. Compile TypeScript with decorators:
   tsc productManager.ts --target ES6 --experimentalDecorators
3. Run the compiled JavaScript:
   node productManager.js
4. Check the console for:
   - Initial inventory
   - Decorator logs of updates
   - Updated inventory

