// DOM Elements
const productContainer = document.getElementById("products");
const categoryFilter = document.getElementById("categoryFilter");
const priceSort = document.getElementById("priceSort");
const loadingElement = document.getElementById("loading");

let allProducts = []; // Store products globally

// ================= FETCH PRODUCTS =================
async function fetchProducts() {
    try {
        loadingElement.textContent = "Loading products...";
        productContainer.innerHTML = "";

        const response = await fetch("products.json");

        if (!response.ok) {
            throw new Error("Failed to fetch products");
        }

        const data = await response.json();
        allProducts = data;

        populateCategories(data);
        renderProducts(data);

        loadingElement.textContent = "";

    } catch (error) {
        loadingElement.textContent = "";
        productContainer.innerHTML =
            `<p style="color:red;">Error loading products. Please try again.</p>`;
        console.error(error);
    }
}

// ================= RENDER PRODUCTS =================
function renderProducts(products) {
    productContainer.innerHTML = "";

    if (products.length === 0) {
        productContainer.innerHTML = "<p>No products found.</p>";
        return;
    }

    const fragment = document.createDocumentFragment();

    products.forEach(product => {
        const col = document.createElement("div");
        col.className = "col-md-4 mb-4";

        col.innerHTML = `
            <div class="card h-100 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">${product.title}</h5>
                    <p class="card-text text-muted">Category: ${product.category}</p>
                    <p class="card-text fw-bold text-success">$${product.price}</p>
                </div>
            </div>
        `;

        fragment.appendChild(col);
    });

    productContainer.appendChild(fragment);
}

// ================= POPULATE CATEGORY DROPDOWN =================
function populateCategories(products) {
    const categories = [...new Set(products.map(p => p.category))];

    categoryFilter.innerHTML = `<option value="all">All Categories</option>`;

    categories.forEach(category => {
        const option = document.createElement("option");
        option.value = category;
        option.textContent = category;
        categoryFilter.appendChild(option);
    });
}

// ================= FILTER & SORT =================
function applyFilters() {
    let filteredProducts = [...allProducts];

    // Filter by category
    if (categoryFilter.value !== "all") {
        filteredProducts = filteredProducts.filter(
            product => product.category === categoryFilter.value
        );
    }

    // Sort by price
    if (priceSort.value === "low") {
        filteredProducts.sort((a, b) => a.price - b.price);
    } else if (priceSort.value === "high") {
        filteredProducts.sort((a, b) => b.price - a.price);
    }

    renderProducts(filteredProducts);
}

// ================= EVENT LISTENERS =================
categoryFilter.addEventListener("change", applyFilters);
priceSort.addEventListener("change", applyFilters);

// ================= INITIAL LOAD =================
fetchProducts();
