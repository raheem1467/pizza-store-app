// 1️⃣ Define Contact Interface
interface Contact {
    id: number;
    name: string;
    email: string;
    phone: string;
}

// 2️⃣ Implement ContactManager Class
class ContactManager {

    private contacts: Contact[] = [];

    // Add Contact
    public addContact(contact: Contact): void {

        const exists = this.contacts.find(c => c.id === contact.id);

        if (exists) {
            console.error(`❌ Error: Contact with ID ${contact.id} already exists.`);
            return;
        }

        this.contacts.push(contact);
        console.log(`✅ Contact "${contact.name}" added successfully.`);
    }

    // View Contacts
    public viewContacts(): Contact[] {

        if (this.contacts.length === 0) {
            console.log("📭 No contacts available.");
        }

        return this.contacts;
    }

    // Modify Contact
    public modifyContact(id: number, updatedContact: Partial<Contact>): void {

        const contact = this.contacts.find(c => c.id === id);

        if (!contact) {
            console.error(`❌ Error: Contact with ID ${id} does not exist.`);
            return;
        }

        Object.assign(contact, updatedContact);

        console.log(`✅ Contact with ID ${id} modified successfully.`);
    }

    // Delete Contact
    public deleteContact(id: number): void {

        const index = this.contacts.findIndex(c => c.id === id);

        if (index === -1) {
            console.error(`❌ Error: Contact with ID ${id} does not exist.`);
            return;
        }

        const deleted = this.contacts.splice(index, 1);

        console.log(`✅ Contact "${deleted[0].name}" deleted successfully.`);
    }
}

// 4️⃣ Testing the ContactManager

const manager = new ContactManager();

// Add Contacts
manager.addContact({
    id: 1,
    name: "Rahim",
    email: "rahim@example.com",
    phone: "9876543210"
});

manager.addContact({
    id: 2,
    name: "Aisha",
    email: "aisha@example.com",
    phone: "9123456780"
});

// View Contacts
console.log("📋 Contact List:", manager.viewContacts());

// Modify Contact
manager.modifyContact(1, {
    email: "rahim.new@example.com"
});

// Attempt Modify Non-Existing Contact
manager.modifyContact(5, { name: "Test" });

// Delete Contact
manager.deleteContact(2);

// Attempt Delete Non-Existing Contact
manager.deleteContact(10);

// Final Contact List
console.log("📋 Final Contact List:", manager.viewContacts());
