// challenge5.js
// Day 17 – Challenge 5: HTTP Module

const http = require('http');
const fs = require('fs').promises;
const path = require('path');

const port = 3000;

const server = http.createServer(async (req, res) => {
  if (req.url === '/' || req.url === '/index.html') {
    try {
      const content = await fs.readFile(path.join(__dirname, 'static', 'index.html'));
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(content);
    } catch (e) {
      res.writeHead(500);
      res.end('Error loading page.');
    }
  } else if (req.url === '/about' || req.url === '/about.html') {
    try {
      const content = await fs.readFile(path.join(__dirname, 'static', 'about.html'));
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(content);
    } catch (e) {
      res.writeHead(500);
      res.end('Error loading page.');
    }
  } else {
    res.writeHead(404);
    res.end('Not found');
  }
});

server.listen(port, () => console.log(`Server running at http://localhost:${port}`));
