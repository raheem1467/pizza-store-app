// challenge6.js
// Day 17 – Challenge 6: Events Module

const EventEmitter = require('events');
const emitter = new EventEmitter();

// register listeners
emitter.on('userLoggedIn', (user) => {
  console.log(`User ${user} logged in.`);
});

emitter.on('userLoggedOut', (user) => {
  console.log(`User ${user} logged out.`);
});

// bonus listener
emitter.on('sessionExpired', (user) => {
  console.log(`Session for ${user} expired.`);
});

// trigger events
emitter.emit('userLoggedIn', 'John');
emitter.emit('userLoggedOut', 'John');

// bonus: emit after 5 seconds
setTimeout(() => {
  emitter.emit('sessionExpired', 'John');
}, 5000);
