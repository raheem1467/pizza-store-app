// challenge4.js
// Day 17 – Challenge 4: File System (fs) Module

const fs = require('fs').promises;
const readline = require('readline');

async function main() {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  rl.question('Enter feedback: ', async (answer) => {
    try {
      // write to feedback.txt
      await fs.writeFile('feedback.txt', answer, 'utf8');
      console.log('Data written successfully.');

      console.log('Reading file...');
      const data = await fs.readFile('feedback.txt', 'utf8');
      console.log(data);
    } catch (err) {
      console.error('Error:', err);
    }
    rl.close();
  });
}

main();
