# Node.js Assessment 2

This directory contains solutions for Day 17 challenges covering Node.js core modules (fs, http, events).

## 📁 Folder structure
```
nodejs-assessment2/
├── challenge4.js            # fs/promises write/read
├── challenge5.js            # http server with routing
├── challenge6.js            # EventEmitter demo
├── package.json             # scripts for each challenge
├── static/                  # HTML files for challenge 5 bonus
│   ├── index.html
│   └── about.html
└── screenshots/             # place your screenshots here
```

## 🔧 Setup & requirements
- Node.js installed (v12+)
- No external npm packages required
- All commands run from this folder

## 🚀 Running the challenges
1. **Challenge 4 – fs module**
   ```bash
   npm run challenge4
   ```
   - When prompted type: `Node.js is awesome!` and press Enter.
   - Expected output:
     ```
     Enter feedback: Node.js is awesome!
     Data written successfully.
     Reading file...
     Node.js is awesome!
     ```
   - Screenshot after the final line (before program exits) and save in `screenshots/ch4.png`.

2. **Challenge 5 – http module**
   ```bash
   npm run challenge5
   ```
   - Open a browser and visit `http://localhost:3000` → should show "Hello from Node.js Server".
   - Visit `http://localhost:3000/about` → shows "About Page".
   - Press `Ctrl+C` in terminal to stop the server.
   - Take screenshots of each route result and save as `screenshots/ch5-home.png` and `screenshots/ch5-about.png`.

3. **Challenge 6 – events module**
   ```bash
   npm run challenge6
   ```
   - Output should be:
     ```
     User John logged in.
     User John logged out.
     (after ~5 s) Session for John expired.
     ```
   - Take a screenshot once all messages have appeared (`screenshots/ch6.png`).

---

### 📌 Notes for full marks
- **fs.promises** is used with async/await for write/read.
- HTTP server handles multiple routes and serves static HTML (bonus).
- **EventEmitter** listeners registered before events, including timed custom event.
- Screenshots folder is ready for evidence; use provided commands to reproduce output.

Follow the instructions above, capture the outputs, and you’ll have everything needed to score full credit. Enjoy! 🎓