// src/components/RenderStatus.jsx
import React from 'react';

const RenderStatus = ({ children, status }) => {
  return (
    <div>
      {status === 'loading' && <p>Loading data...</p>}
      {status === 'error' && <p>Error fetching data!</p>}
      {status === 'success' && children}
    </div>
  );
};

export default RenderStatus;
