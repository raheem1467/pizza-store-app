// src/components/withLoader.jsx
import React from 'react';

const withLoader = (WrappedComponent) => {
  return ({ loading, ...props }) => {
    if (loading) return <div className="spinner">Loading...</div>;
    return <WrappedComponent {...props} />;
  };
};

export default withLoader;
