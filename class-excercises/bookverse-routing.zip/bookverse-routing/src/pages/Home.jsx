// src/pages/Home.jsx
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import withLoader from '../components/withLoader';
import RenderStatus from '../components/RenderStatus';

const Home = () => {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState('loading');

  useEffect(() => {
    axios.get('http://localhost:3001/books')
      .then(res => {
        setBooks(res.data);
        setLoading(false);
        setStatus('success');
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
        setStatus('error');
      });
  }, []);

  return (
    <RenderStatus status={status}>
      <div className="book-list">
        {books.map(book => (
          <div key={book.id} className="book-card">
            <h3>{book.title}</h3>
            <p>{book.author}</p>
            <Link to={`/book/${book.id}`}>View Details</Link>
          </div>
        ))}
      </div>
    </RenderStatus>
  );
};

export default withLoader(Home);
