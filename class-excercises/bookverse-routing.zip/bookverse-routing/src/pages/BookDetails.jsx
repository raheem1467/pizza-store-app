// src/pages/BookDetails.jsx
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import withLoader from '../components/withLoader';
import RenderStatus from '../components/RenderStatus';

const BookDetails = () => {
  const { id } = useParams();
  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState('loading');

  useEffect(() => {
    axios.get(`http://localhost:3001/books/${id}`)
      .then(res => {
        setBook(res.data);
        setLoading(false);
        setStatus('success');
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
        setStatus('error');
      });
  }, [id]);

  return (
    <RenderStatus status={status}>
      {book && (
        <div className="book-details fade-in">
          <h2>{book.title}</h2>
          <h4>by {book.author}</h4>
          <p>{book.description}</p>
          <Link to="/">Back to Home</Link>
        </div>
      )}
    </RenderStatus>
  );
};

export default withLoader(BookDetails);
