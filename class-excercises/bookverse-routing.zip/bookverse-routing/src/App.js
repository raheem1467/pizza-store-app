// src/App.jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import BookDetails from './pages/BookDetails';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home loading={false} />} />
        <Route path="/book/:id" element={<BookDetails loading={false} />} />
      </Routes>
    </Router>
  );
};

export default App;
