// hello-node.js
// Challenge 1: Node.js Fundamentals

// Log Node.js version
console.log("Node.js version:", process.version);

// Log current file name and directory
console.log("Current file:", __filename);
console.log("Current directory:", __dirname);

// Welcome message every 3 seconds
let count = 0;
const intervalId = setInterval(() => {
  count += 1;
  console.log("Welcome to Node.js! Message #" + count);
}, 3000);

// Bonus: stop timer logic after 10 seconds
setTimeout(() => {
  clearInterval(intervalId);
  console.log("Stopped welcome messages after 10 seconds.");
}, 10000);
