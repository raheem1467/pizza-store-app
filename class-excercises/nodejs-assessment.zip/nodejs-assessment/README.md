# Node.js Assessment

This folder contains the solutions for the three challenges in the "Introduction to Node.js & Basics" assignment.

## 📁 Folder structure
```
nodejs-assessment/
├── hello-node.js      # Challenge 1
├── index.js           # Challenge 2 (npm + chalk/figlet)
├── greet.js           # Challenge 3 CLI app
├── package.json       # npm project file with scripts and deps
└── README.md          # this file
```

## 🧪 Prerequisites
- Node.js installed (v12+ recommended)
- A terminal (PowerShell or cmd)

## 🚀 Setup
1. Open a terminal and navigate to the `nodejs-assessment` folder:
   ```bash
   cd c:\Users\rahee\OneDrive\Desktop\assessmet\sql_assessment\nodejs-assessment
   ```
2. Install dependencies (chalk, figlet, moment):
   ```bash
   npm install
   ```
   This will create a `node_modules` folder and update `package-lock.json`.

## ✅ Challenge 1: Node.js Fundamentals
Run the script directly with Node:
```bash
node hello-node.js
```
You should see output similar to:
```
Node.js version: v18.17.1
Current file: C:\...\hello-node.js
Current directory: C:\...\nodejs-assessment
Welcome to Node.js! Message #1
Welcome to Node.js! Message #2
...
Stopped welcome messages after 10 seconds.
```
Messages appear every 3 seconds and clear after 10 seconds (bonus behavior). You can also use the npm script:
```bash
npm run hello
```

## ✅ Challenge 2: Understanding npm
The `index.js` file uses external modules to render a stylized banner.
Run it with:
```bash
npm start
```
or
```bash
node index.js
```
You should see a colored ASCII-art "Welcome to Node.js" message.

## ✅ Challenge 3: Simple CLI Application
Execute `greet.js` with a name argument:
```bash
node greet.js John
```
Output example:
```
Hello, John! Today is Fri Mar 7 2025, 10:45 AM
```
If `moment` is installed it will format the date nicely; otherwise it falls back to the default `Date.toString()`.

Use the npm script too:
```bash
npm run greet -- John
```
(The `--` passes additional args to the script.)

---

### 📌 Notes for Full Marks
- Node versions and global objects are logged
- Timers used correctly with `setInterval` / `clearInterval`
- `npm init` was simulated via package.json; dependencies are listed
- Scripts provided (`start`, `hello`, `greet`)
- `process.argv` used for CLI input and an external package (`moment`) demonstrates npm usage

Feel free to modify or extend the code for experimentation. Good luck on your assessment! 🎓