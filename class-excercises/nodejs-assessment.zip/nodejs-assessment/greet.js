// greet.js
// Challenge 3: Creating a Simple Node Application

// Read name from command line arguments
const argv = process.argv.slice(2);
const name = argv[0] || 'Guest';

// Optionally use moment if available for formatted date/time
let now = new Date();
let formatted;
try {
  const moment = require('moment');
  formatted = moment(now).format('ddd MMM D YYYY, h:mm A');
} catch (e) {
  // fallback if moment isn't installed
  formatted = now.toString();
}

console.log(`Hello, ${name}! Today is ${formatted}`);
