// index.js
// Challenge 2: Understanding npm
// Use chalk and figlet to display a stylized welcome message

const figlet = require('figlet');
// chalk v5 is ESM-only; require returns an object with a default export.
const chalkImport = require('chalk');
const chalk = chalkImport.default || chalkImport;

figlet('Welcome to Node.js', function(err, data) {
  if (err) {
    console.log('Something went wrong with figlet...');
    console.dir(err);
    return;
  }
  console.log(chalk.green(data));
});
