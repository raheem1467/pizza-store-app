import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import BookList from "./components/BookList";
import AuthorInfo from "./components/AuthorInfo";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      books: [
        { id: 1, title: "Book One", author: "Author A", bio: "Bio of Author A", topBooks: ["Book One", "Book Four", "Book Seven"] },
        { id: 2, title: "Book Two", author: "Author B", bio: "Bio of Author B", topBooks: ["Book Two", "Book Five", "Book Eight"] },
        { id: 3, title: "Book Three", author: "Author C", bio: "Bio of Author C", topBooks: ["Book Three", "Book Six", "Book Nine"] },
      ],
      selectedAuthor: null,
    };

    // Ref for search input (uncontrolled component)
    this.searchInputRef = React.createRef();
  }

  componentDidMount() {
    console.log("App mounted. Books loaded.");
  }

  handleBookClick = (book) => {
    this.setState({ selectedAuthor: book });
  };

  focusSearchInput = () => {
    if (this.searchInputRef.current) {
      this.searchInputRef.current.focus();
    }
  };

  render() {
    const { books, selectedAuthor } = this.state;

    return (
      <div className="container mt-4">
        <h2>BookVerse</h2>

        {/* Search Box with Uncontrolled Ref */}
        <div className="mb-3">
          <input type="text" placeholder="Search books..." ref={this.searchInputRef} className="form-control w-50 d-inline-block" />
          <button className="btn btn-primary ms-2" onClick={this.focusSearchInput}>
            Focus Search
          </button>
        </div>

        {/* Book List */}
        <BookList books={books} onBookClick={this.handleBookClick} />

        {/* Author Info */}
        {selectedAuthor && (
          <AuthorInfo
            authorName={selectedAuthor.author}
            bio={selectedAuthor.bio}
            topBooks={selectedAuthor.topBooks}
          />
        )}
      </div>
    );
  }
}

export default App;
