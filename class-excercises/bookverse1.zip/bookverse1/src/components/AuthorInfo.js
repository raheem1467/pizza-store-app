import React from "react";

class AuthorInfo extends React.Component {
  componentDidMount() {
    console.log("AuthorInfo mounted. Data loaded for author:", this.props.authorName);
  }

  render() {
    const { authorName, bio, topBooks } = this.props;

    return (
      <div className="card mt-3 p-3 bg-light">
        <h4>Author: {authorName}</h4>
        <p>{bio}</p>
        <h6>Top 3 Books:</h6>
        <ul>
          {topBooks.map((book, index) => (
            <li key={index}>{book}</li>
          ))}
        </ul>
      </div>
    );
  }
}

export default AuthorInfo;
