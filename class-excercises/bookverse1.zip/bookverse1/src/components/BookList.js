import React from "react";
import BookCard from "./BookCard";

class BookList extends React.Component {
  render() {
    const { books, onBookClick } = this.props;
    return (
      <div className="d-flex flex-wrap">
        {books.map((book) => (
          <BookCard
            key={book.id}
            title={book.title}
            author={book.author}
            onClick={() => onBookClick(book)}
          />
        ))}
      </div>
    );
  }
}

export default BookList;
