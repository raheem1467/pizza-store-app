import React from "react";
import PropTypes from "prop-types";

class BookCard extends React.Component {
  render() {
    const { title, author, onClick } = this.props;
    return (
      <div className="card m-2" style={{ width: "12rem", cursor: "pointer" }} onClick={onClick}>
        <div className="card-body">
          <h5 className="card-title">{title}</h5>
          <p className="card-text">{author}</p>
        </div>
      </div>
    );
  }
}

BookCard.propTypes = {
  title: PropTypes.string.isRequired,
  author: PropTypes.string.isRequired,
  onClick: PropTypes.func.isRequired,
};

export default BookCard;
