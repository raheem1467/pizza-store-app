const express = require("express");

const courseRoutes = require("./routes/courseRoutes");
const userRoutes = require("./routes/userRoutes");

const app = express();

app.use(express.json());

app.use("/api/courses", courseRoutes);
app.use("/api/users", userRoutes);

app.get("/status", (req, res) => {
  res.send("App is live");
});

const PORT = process.env.PORT || 5000;

if (require.main === module) {
  app.listen(PORT, () => {
    console.log("Server running on port", PORT);
  });
}

module.exports = app;