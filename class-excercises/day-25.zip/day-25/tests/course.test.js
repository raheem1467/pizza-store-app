const request = require("supertest");
const chai = require("chai");
const expect = chai.expect;

const app = require("../server");

describe("Course API", () => {

  it("should GET all courses", async () => {

    const res = await request(app).get("/api/courses");

    expect(res.status).to.equal(200);
    expect(res.body).to.be.an("array");

  });

});