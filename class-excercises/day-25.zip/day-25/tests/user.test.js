const request = require("supertest");
const chai = require("chai");
const expect = chai.expect;

const app = require("../server");

describe("User API Integration Test", () => {

  it("GET /api/users should return users", async () => {

    const res = await request(app).get("/api/users");

    expect(res.status).to.equal(200);
    expect(res.body).to.be.an("array");

  });

});