const users = require("../data/users");

exports.getUsers = (req, res) => {
  res.json(users);
};

exports.createUser = (req, res) => {
  const { name, role } = req.body;

  const newUser = {
    id: users.length + 1,
    name,
    role
  };

  users.push(newUser);

  res.json(newUser);
};