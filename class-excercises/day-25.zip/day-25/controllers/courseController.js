const courses = require("../data/courses");

exports.getCourses = (req, res) => {
  res.json(courses);
};

exports.createCourse = (req, res) => {
  const { name, duration } = req.body;

  const newCourse = {
    id: courses.length + 1,
    name,
    duration
  };

  courses.push(newCourse);

  res.json({
    message: "Course created",
    course: newCourse
  });
};