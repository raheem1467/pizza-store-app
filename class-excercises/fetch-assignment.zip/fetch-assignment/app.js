const App = (function () {

    const POSTS_URL = "https://jsonplaceholder.typicode.com/posts";
    const TODOS_URL = "https://jsonplaceholder.typicode.com/todos";

    const postsContainer = document.getElementById("posts");
    const todosContainer = document.getElementById("todos");
    const loader = document.getElementById("loader");
    const errorBox = document.getElementById("error");

    // ===== Utility Functions =====

    const showLoader = () => loader.classList.remove("hidden");
    const hideLoader = () => loader.classList.add("hidden");

    const showError = (message) => {
        errorBox.textContent = message;
        errorBox.classList.remove("hidden");
    };

    const clearError = () => {
        errorBox.textContent = "";
        errorBox.classList.add("hidden");
    };

    // ===== Fetch Handler (Reusable) =====

    const fetchData = async (url) => {
        try {
            showLoader();
            clearError();

            const response = await fetch(url);

            if (!response.ok) {
                throw new Error(`HTTP Error: ${response.status}`);
            }

            const data = await response.json();

            if (!Array.isArray(data)) {
                throw new Error("Unexpected data format received.");
            }

            return data;

        } catch (error) {
            showError("Failed to fetch data. Please try again.");
            console.error("Fetch Error:", error.message);
            return [];
        } finally {
            hideLoader();
        }
    };

    // ===== Render Functions =====

    const renderPosts = async () => {
        postsContainer.innerHTML = "";
        const posts = await fetchData(POSTS_URL);

        posts.slice(0, 10).forEach(post => {
            const div = document.createElement("div");
            div.className = "post";
            div.innerHTML = `<strong>${post.title}</strong><p>${post.body}</p>`;
            postsContainer.appendChild(div);
        });
    };

    const renderTodos = async () => {
        todosContainer.innerHTML = "";
        const todos = await fetchData(TODOS_URL);

        todos.slice(0, 15).forEach(todo => {
            const div = document.createElement("div");
            div.className = `todo ${todo.completed ? "completed" : ""}`;
            div.textContent = todo.title;
            todosContainer.appendChild(div);
        });
    };

    // ===== Event Binding =====

    const init = () => {
        document.getElementById("loadPosts")
            .addEventListener("click", renderPosts);

        document.getElementById("loadTodos")
            .addEventListener("click", renderTodos);
    };

    // ===== Revealed Methods =====
    return {
        init
    };

})();

// Initialize Application
document.addEventListener("DOMContentLoaded", App.init);
