-- ===============================
-- USER STORY 1 - DATABASE SETUP
-- ===============================

-- 1. Create Database
CREATE DATABASE TechNovaDB;

-- 2. Use Database
USE TechNovaDB;

-- 3. Department Table
CREATE TABLE Department (
    DeptID INT PRIMARY KEY,
    DeptName VARCHAR(100) NOT NULL UNIQUE,
    Location VARCHAR(100) NOT NULL
);

-- 4. Employee Table
CREATE TABLE Employee (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(100) NOT NULL,
    Gender ENUM('M','F','Other'),
    DOB DATE NOT NULL,
    HireDate DATE NOT NULL,
    DeptID INT,
    CONSTRAINT fk_emp_dept FOREIGN KEY (DeptID)
        REFERENCES Department(DeptID)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

-- 5. Project Table
CREATE TABLE Project (
    ProjectID INT PRIMARY KEY,
    ProjectName VARCHAR(100) NOT NULL,
    DeptID INT,
    StartDate DATE,
    EndDate DATE,
    CONSTRAINT fk_proj_dept FOREIGN KEY (DeptID)
        REFERENCES Department(DeptID)
);

-- 6. Performance Table
CREATE TABLE Performance (
    EmpID INT,
    ProjectID INT,
    Rating DECIMAL(3,2) CHECK (Rating BETWEEN 1 AND 5),
    ReviewDate DATE,
    PRIMARY KEY (EmpID, ProjectID),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID)
);

-- 7. Reward Table
CREATE TABLE Reward (
    EmpID INT,
    RewardMonth DATE,
    RewardAmount DECIMAL(10,2),
    PRIMARY KEY (EmpID, RewardMonth),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);

-- 8. Indexes
CREATE INDEX idx_empname ON Employee(EmpName);
CREATE INDEX idx_deptid ON Employee(DeptID);

-- ===============================
-- USER STORY 2 - DML
-- ===============================

-- Insert Departments
INSERT INTO Department VALUES
(101,'IT','Bangalore'),
(102,'HR','Delhi'),
(103,'Finance','Mumbai'),
(104,'Marketing','Hyderabad'),
(105,'Sales','Chennai');

-- Insert Employees
INSERT INTO Employee VALUES
(1,'Asha','F','1990-07-12','2018-06-10',101),
(2,'Raj','M','1988-04-09','2020-03-22',102),
(3,'Neha','F','1995-01-15','2021-08-05',101),
(4,'Arjun','M','1992-11-25','2019-01-10',103),
(5,'Meera','F','1993-05-19','2022-07-01',104);

-- Insert Projects
INSERT INTO Project VALUES
(201,'ERP System',101,'2022-01-01','2022-12-31'),
(202,'HR Automation',102,'2021-05-01','2022-05-01'),
(203,'Financial Audit',103,'2023-01-01','2023-06-30'),
(204,'Market Research',104,'2023-03-01','2023-09-01'),
(205,'Sales Boost',105,'2022-04-01','2022-10-01');

-- Insert Performance
INSERT INTO Performance VALUES
(1,201,4.5,'2023-01-15'),
(2,202,3.8,'2023-02-10'),
(3,201,4.2,'2023-03-05'),
(4,203,4.9,'2023-04-01'),
(5,204,3.5,'2023-05-10');

-- Insert Rewards
INSERT INTO Reward VALUES
(1,'2024-01-01',2500),
(2,'2024-02-01',1500),
(3,'2024-03-01',900),
(4,'2024-04-01',3000),
(5,'2024-05-01',1200);

-- Update Employee Department
UPDATE Employee
SET DeptID = 105
WHERE EmpID = 5;

-- Delete Reward less than 1000
DELETE FROM Reward
WHERE RewardAmount < 1000;

-- ===============================
-- USER STORY 3 - QUERIES
-- ===============================

-- 1. Employees joined after 2019
SELECT * FROM Employee
WHERE HireDate > '2019-01-01';

-- 2. Average Rating per Department
SELECT d.DeptName, AVG(p.Rating) AS AvgRating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
GROUP BY d.DeptName;

-- 3. Employees with Age
SELECT EmpName,
TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age
FROM Employee;

-- 4. Total Rewards Current Year
SELECT SUM(RewardAmount) AS TotalRewards
FROM Reward
WHERE YEAR(RewardMonth) = YEAR(CURDATE());

-- 5. Rewards > 2000
SELECT e.EmpName, r.RewardAmount
FROM Reward r
JOIN Employee e ON r.EmpID = e.EmpID
WHERE r.RewardAmount > 2000;

-- ===============================
-- USER STORY 4 - ADVANCED QUERIES
-- ===============================

-- 1. Employee + Department + Project + Rating
SELECT e.EmpName, d.DeptName, pr.ProjectName, p.Rating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
JOIN Project pr ON p.ProjectID = pr.ProjectID;

-- 2. Highest Rated Employee per Department
SELECT e.EmpName, d.DeptName, p.Rating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
WHERE p.Rating = (
    SELECT MAX(p2.Rating)
    FROM Performance p2
    JOIN Employee e2 ON p2.EmpID = e2.EmpID
    WHERE e2.DeptID = d.DeptID
);

-- 3. Employees with No Rewards
SELECT EmpName
FROM Employee
WHERE EmpID NOT IN (
    SELECT EmpID FROM Reward
);

-- ===============================
-- USER STORY 5 - TRANSACTION
-- ===============================

START TRANSACTION;

INSERT INTO Employee VALUES
(6,'Kiran','M','1996-02-10','2024-01-01',101);

INSERT INTO Performance VALUES
(6,201,4.0,'2024-02-01');

COMMIT;

-- Slow Query Example
EXPLAIN
SELECT e.EmpName, d.DeptName, pr.ProjectName
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Project pr ON d.DeptID = pr.DeptID;

-- After Index Already Created
EXPLAIN
SELECT e.EmpName, d.DeptName, pr.ProjectName
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Project pr ON d.DeptID = pr.DeptID;



-- View
CREATE VIEW EmployeePerformanceView AS
SELECT e.EmpName, d.DeptName, p.Rating
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Performance p ON e.EmpID = p.EmpID;

-- Stored Procedure COMMENT
DELIMITER //

CREATE PROCEDURE GetTopPerformers(IN deptName VARCHAR(100))
BEGIN
    SELECT e.EmpName, p.Rating
    FROM Employee e
    JOIN Department d ON e.DeptID = d.DeptID
    JOIN Performance p ON e.EmpID = p.EmpID
    WHERE d.DeptName = deptName
    ORDER BY p.Rating DESC
    LIMIT 3;
END //

DELIMITER ;