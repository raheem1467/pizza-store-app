// server.js
// Day 21 – Middleware & Templates for SkillSphere LMS

const express = require('express');
const path = require('path');

const app = express();
const port = 4000;

// simple in-memory courses array for rendering
const courses = [
  { id: 101, name: 'React Mastery' },
  { id: 102, name: 'Node.js Deep Dive' },
  { id: 103, name: 'Vue for Beginners' }
];

// Challenge 1: logging middleware
app.use((req, res, next) => {
  const ts = new Date().toISOString();
  console.log(`[${req.method}] ${req.url} at ${ts}`);
  next();
});

// Challenge 2: built-in body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// user creation route (POST)
app.post('/users', (req, res) => {
  // request body is already parsed
  res.json({ message: 'User created successfully', data: req.body });
});

// Challenge 3: set up EJS template engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.get('/courses', (req, res) => {
  res.render('courses', { courses });
});

// fallback
app.use((req, res) => {
  res.status(404).send('Route not found');
});

app.listen(port, () => {
  console.log(`SkillSphere LMS server listening at http://localhost:${port}`);
});