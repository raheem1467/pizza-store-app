# Node.js Assessment – Day 21 Middleware & Templates

This folder contains an Express.js application demonstrating logging middleware, body parsing, and EJS templates for a fictional SkillSphere LMS backend.

## 📁 Folder structure

```
ejs-middleware/
├── server.js            # main Express app
├── views/               # EJS templates
│   └── courses.ejs      # list of courses
├── package.json         # dependencies & start script
├── README.md            # this instructions file
└── screenshots/         # save your screenshots here
```

## 🔧 Setup
1. Open a terminal in the folder:
   ```bash
   cd C:\Users\rahee\OneDrive\Desktop\assessmet\sql_assessment\ejs-middleware
   ```
2. Install dependencies:
   ```bash
   npm install
   ```

## 🚀 Running and testing
Start the server:
```bash
npm start
```
It will listen on http://localhost:4000

### Challenge 1 – Logging middleware
- Every request should log `[METHOD] URL at timestamp` in console.
- **Screenshot**: make a few requests (e.g. GET `/`, GET `/courses`) and capture console logs → `screenshots/ch1.png`.

### Challenge 2 – Built-in parsers and POST
- Send a POST request to `http://localhost:4000/users` with JSON or form data.
  Example using `curl`:
  ```bash
  curl -X POST -H "Content-Type: application/json" -d '{"name":"Alice"}' http://localhost:4000/users
  ```
- Response should be:
  ```json
  { "message": "User created successfully", "data": { "name": "Alice" } }
  ```
- **Screenshot**: capture terminal/curl output → `screenshots/ch2.png`.

### Challenge 3 – Dynamic templates with EJS
- Visit `http://localhost:4000/courses` in your browser.
- Page renders a list of courses using the EJS template.
- **Screenshot**: grab browser window showing the course list → `screenshots/ch3.png`.

### 📌 Full‑marks checklist
- Logging middleware is global and lightweight ✅
- `express.json()` and `express.urlencoded()` parse POST data ✅
- POST `/users` returns JSON with received data ✅
- EJS configured as view engine; templates stored in `views` folder ✅
- Template renders a dynamic list of courses without logic mixing ✅

Once you’ve taken screenshots, place them in the `screenshots` directory before submission. Good luck! 🎯