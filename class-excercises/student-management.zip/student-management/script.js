// Store users
let users = [];

// Monthly Activities Array
const activities = [
    { id: 1, activity: "Create project file with tables 12 to 19", subject: "Maths" },
    { id: 2, activity: "Learn Poem – Nature Beauty", subject: "English" },
    { id: 3, activity: "Prepare Solar System Chart", subject: "Science" },
    { id: 4, activity: "Practice Fractions Worksheet", subject: "Maths" },
    { id: 5, activity: "Grammar Exercise – Tenses", subject: "English" }
];

// DOM Elements
const authSection = document.getElementById("authSection");
const welcomeSection = document.getElementById("welcomeSection");
const monthlySection = document.getElementById("monthlySection");
const authMessage = document.getElementById("authMessage");
const subjectSelect = document.getElementById("subjectSelect");
const activityList = document.getElementById("activityList");
const welcomeText = document.getElementById("welcomeText");

// Register
function register() {
    const username = usernameInput();
    const password = passwordInput();

    if (!username || !password) {
        authMessage.textContent = "Please fill all fields";
        return;
    }

    users.push({ username, password });
    authMessage.style.color = "green";
    authMessage.textContent = "Registration Successful!";
}

// Login
function login() {
    const username = usernameInput();
    const password = passwordInput();

    const validUser = users.find(user =>
        user.username === username && user.password === password
    );

    if (validUser) {
        authSection.classList.add("hidden");
        welcomeSection.classList.remove("hidden");
        welcomeText.textContent = `Welcome ${username}`;
        authMessage.textContent = "";
    } else {
        authMessage.style.color = "red";
        authMessage.textContent = "Invalid Credentials";
    }
}

// Show Monthly Page
function showMonthly() {
    welcomeSection.classList.add("hidden");
    monthlySection.classList.remove("hidden");
    loadSubjects();
}

// Load Subjects Dropdown
function loadSubjects() {
    const subjects = [...new Set(activities.map(a => a.subject))];

    subjectSelect.innerHTML = `<option value="">Select Subject</option>`;
    subjects.forEach(subject => {
        subjectSelect.innerHTML += `<option value="${subject}">${subject}</option>`;
    });
}

// Filter Activities
function filterActivities() {
    const selected = subjectSelect.value;
    activityList.innerHTML = "";

    const filtered = activities.filter(a => a.subject === selected);

    filtered.forEach(a => {
        const li = document.createElement("li");
        li.textContent = a.activity;
        activityList.appendChild(li);
    });
}

// Logout
function logout() {
    welcomeSection.classList.add("hidden");
    authSection.classList.remove("hidden");
}

// Back Button
function goBack() {
    monthlySection.classList.add("hidden");
    welcomeSection.classList.remove("hidden");
}

// Helper Functions
function usernameInput() {
    return document.getElementById("username").value.trim();
}

function passwordInput() {
    return document.getElementById("password").value.trim();
}
