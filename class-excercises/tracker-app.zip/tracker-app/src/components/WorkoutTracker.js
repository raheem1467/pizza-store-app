import React, { useState } from "react";
import { useTimer } from "../hooks/useTimer";

export default function WorkoutTracker() {
  const [sets, setSets] = useState(0);
  const { time, setTime } = useTimer();

  return (
    <div className="card p-3 mt-3">
      <h3>Workout Tracker</h3>
      <p>Sets: {sets}</p>
      <p>Timer: {time}s</p>

      <button className="btn btn-primary m-1" onClick={() => setSets(sets + 1)}>
        Add Set
      </button>

      <button className="btn btn-warning m-1" onClick={() => setTime(0)}>
        Reset Timer
      </button>
    </div>
  );
}
