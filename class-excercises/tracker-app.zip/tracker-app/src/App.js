import React, { useContext, useEffect, useState } from "react";
import { ThemeContext } from "./context/ThemeContext";
import WorkoutTracker from "./components/WorkoutTracker";
import ProductList from "./features/products/ProductList";

function App() {
  const { theme, toggleTheme } = useContext(ThemeContext);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const goOnline = () => setIsOffline(false);
    const goOffline = () => setIsOffline(true);

    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);

    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, []);

  return (
    <div
      className={`container-fluid p-4 ${
        theme === "dark" ? "bg-dark text-white" : "bg-light text-dark"
      }`}
      style={{ minHeight: "100vh" }}
    >
      {isOffline && (
        <div className="alert alert-danger text-center">
          You are Offline
        </div>
      )}

      <h1>🚀 React Advanced Dashboard</h1>

      <button className="btn btn-secondary mb-3" onClick={toggleTheme}>
        Toggle Theme
      </button>

      <WorkoutTracker />
      <ProductList />
    </div>
  );
}

export default App;
