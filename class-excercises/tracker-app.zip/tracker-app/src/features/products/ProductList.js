import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchProducts } from "./productSlice";

export default function ProductList() {
  const dispatch = useDispatch();
  const { items, status } = useSelector(state => state.products);

  useEffect(() => {
    dispatch(fetchProducts());
  }, [dispatch]);

  if (status === "loading") return <p>Loading products...</p>;

  return (
    <div className="mt-3">
      <h3>Products</h3>
      {items.map(product => (
        <div key={product.id} className="card p-2 m-2">
          {product.title}
        </div>
      ))}
    </div>
  );
}
