                        // USER STORY 1
To see the output 
go to MockPracticeAssessment/userstory1/
open live server on index.html 
    or
double click on the index.html page


                        // USER STORY 2
to see the output 
go to userstory2/dashboard.html
and click on live server 
it will open on 
http://127.0.0.1:5500/userstory2/dashboard.html

                        // USER STORY 3
to see the output 
go to MockPracticeAssessment/userstory3/
and run the command -> tsc CustomerModule.ts 
it will generate -> CustomerModule.js
now open live server on index.html 
    or
double click on the index.html page
then go to the console window you will see the output


                       // OutPut Images

the required output images are stored in screenshots folder and in that there are seperate categories for 
userstory1 
userstory2
userstory3




