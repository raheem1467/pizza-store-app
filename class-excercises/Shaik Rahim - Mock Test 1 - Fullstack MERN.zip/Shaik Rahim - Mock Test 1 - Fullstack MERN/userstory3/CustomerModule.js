var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __setFunctionName = (this && this.__setFunctionName) || function (f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
};
// Enum for Membership Type
var MembershipType;
(function (MembershipType) {
    MembershipType["Regular"] = "Regular";
    MembershipType["Premium"] = "Premium";
    MembershipType["VIP"] = "VIP";
})(MembershipType || (MembershipType = {}));
// Simple Decorator
function LogCreation(constructor) {
    console.log("Customer class is created");
}
// Base Class
class Person {
    constructor(name) {
        this.name = name;
    }
}
// Apply Decorator
let Customer = (() => {
    let _classDecorators = [LogCreation];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = Person;
    var Customer = _classThis = class extends _classSuper {
        constructor(id, name, membership, contact) {
            super(name);
            this.id = id;
            this.membership = membership;
            this.contact = contact;
        }
        displayInfo() {
            console.log("Customer Info:");
            console.log("ID:", this.id);
            console.log("Name:", this.name);
            console.log("Membership:", this.membership);
            console.log("Email:", this.contact[0]);
            console.log("Phone:", this.contact[1]);
        }
    };
    __setFunctionName(_classThis, "Customer");
    (() => {
        var _a;
        const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create((_a = _classSuper[Symbol.metadata]) !== null && _a !== void 0 ? _a : null) : void 0;
        __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
        Customer = _classThis = _classDescriptor.value;
        if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        __runInitializers(_classThis, _classExtraInitializers);
    })();
    return Customer = _classThis;
})();
// Customer Manager Class
class CustomerManager {
    constructor() {
        this.customers = [];
    }
    addCustomer(customer) {
        this.customers.push(customer);
    }
    // Iterator
    *getCustomers() {
        for (let customer of this.customers) {
            yield customer;
        }
    }
}
// Usage Example
const manager = new CustomerManager();
const customer1 = new Customer(1, "Rahul Sharma", MembershipType.Premium, ["rahul@email.com", 9876543210]);
manager.addCustomer(customer1);
// Iterate through customers
for (let cust of manager.getCustomers()) {
    cust.displayInfo();
}
