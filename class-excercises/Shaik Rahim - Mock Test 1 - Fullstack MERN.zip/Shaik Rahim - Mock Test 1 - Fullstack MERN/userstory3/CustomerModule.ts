
enum MembershipType {
    Regular = "Regular",
    Premium = "Premium",
    VIP = "VIP"
}


type ContactInfo = [string, number]; 


interface ICustomer {
    id: number;
    name: string;
    membership: MembershipType;
    contact: ContactInfo;
    displayInfo(): void;
}

function LogCreation(constructor: Function) {
    console.log("Customer class is created");
}


class Person {
    constructor(public name: string) {}
}


@LogCreation
class Customer extends Person implements ICustomer {

    constructor(
        public id: number,
        name: string,
        public membership: MembershipType,
        public contact: ContactInfo
    ) {
        super(name);
    }

    displayInfo(): void {
        console.log("Customer Info:");
        console.log("ID:", this.id);
        console.log("Name:", this.name);
        console.log("Membership:", this.membership);
        console.log("Email:", this.contact[0]);
        console.log("Phone:", this.contact[1]);
    }
}

class CustomerManager {
    private customers: Customer[] = [];

    addCustomer(customer: Customer): void {
        this.customers.push(customer);
    }

  
    *getCustomers() {
        for (let customer of this.customers) {
            yield customer;
        }
    }
}
const manager = new CustomerManager();

const customer1 = new Customer(
    1,
    "Rahul Sharma",
    MembershipType.Premium,
    ["rahul@email.com", 9876543210]
);

manager.addCustomer(customer1);

for (let cust of manager.getCustomers()) {
    cust.displayInfo();
}
