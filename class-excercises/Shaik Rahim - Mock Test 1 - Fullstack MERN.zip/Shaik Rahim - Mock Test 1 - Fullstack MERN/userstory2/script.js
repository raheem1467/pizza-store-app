const eventContainer = document.getElementById("eventContainer");
const categoryFilter = document.getElementById("categoryFilter");

let events = [];


const fetchEvents = async () => {
    try {
        const response = await fetch("events.json");

        if (!response.ok) {
            throw new Error("Failed to fetch events");
        }

        events = await response.json();
        displayEvents(events);

    } catch (error) {
        console.log("Error:", error.message);
        eventContainer.innerHTML = "<p class='text-danger'>Could not load events.</p>";
    }
};


const displayEvents = (eventList) => {
    eventContainer.innerHTML = "";

    eventList.forEach(event => {
        const { name, category, date } = event;

        const card = `
            <div class="col-md-4 mb-3">
                <div class="card p-3">
                    <h5>${name}</h5>
                    <p>Category: ${category}</p>
                    <p>Date: ${date}</p>
                </div>
            </div>
        `;

        eventContainer.innerHTML += card;
    });
};


categoryFilter.addEventListener("change", () => {
    const selected = categoryFilter.value;

    if (selected === "all") {
        displayEvents(events);
    } else {
        const filtered = events.filter(event => event.category === selected);
        displayEvents(filtered);
    }
});



fetchEvents();
