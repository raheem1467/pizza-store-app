// Day 8: Indexing & Aggregation Demo for BookVerse

//use BookVerseDB;

// ===== USER STORY 1: INDEXING & QUERY OPTIMIZATION =====

// 1. Create indexes on frequently queried fields
print("Creating Indexes...");
db.Books.createIndex({ genre: 1 });
db.Books.createIndex({ authorId: 1 });
db.Books.createIndex({ "ratings.score": 1 });

// 2. Explain query performance before and after indexes
print("Explain plan for genre query:");
printjson(db.Books.find({ genre: "Fantasy" }).explain("executionStats"));

// 3. Drop an unnecessary index (example: drop index on ratings.score)
print("Dropping index on ratings.score");
db.Books.dropIndex("ratings.score_1");

// ===== USER STORY 2: AGGREGATION FRAMEWORK =====

print("========== AGGREGATION PIPELINES ==========");

// 1. Average rating per book
print("--- Average rating per book ---");
db.Books.aggregate([
  { $unwind: "$ratings" },
  { $group: { _id: "$title", avgRating: { $avg: "$ratings.score" } } },
  { $sort: { avgRating: -1 } }
]).forEach(printjson);

// 2. Top 3 highest-rated books
print("--- Top 3 highest-rated books ---");
db.Books.aggregate([
  { $unwind: "$ratings" },
  { $group: { _id: "$title", avgRating: { $avg: "$ratings.score" } } },
  { $sort: { avgRating: -1 } },
  { $limit: 3 }
]).forEach(printjson);

// 3. Count of books per genre
print("--- Count of books per genre ---");
db.Books.aggregate([
  { $group: { _id: "$genre", count: { $sum: 1 } } }
]).forEach(printjson);

// 4. Authors with more than 2 books
print("--- Authors with more than 2 books ---");
db.Books.aggregate([
  { $group: { _id: "$authorId", booksCount: { $sum: 1 } } },
  { $match: { booksCount: { $gt: 2 } } }
]).forEach(printjson);

// 5. Total reward points (sum of all ratings) per author
print("--- Total reward points per author ---");
db.Books.aggregate([
  { $unwind: "$ratings" },
  { $group: { _id: "$authorId", totalPoints: { $sum: "$ratings.score" } } }
]).forEach(printjson);