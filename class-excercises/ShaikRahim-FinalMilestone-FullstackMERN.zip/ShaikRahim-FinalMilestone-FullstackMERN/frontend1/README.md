
---

# **Frontend README.md**

```markdown
# FitTrack Frontend (MERN Fullstack Milestone Project)

## Overview

This frontend is a **React application** for the FitTrack personal fitness portal. Users can:

- View all available fitness programs
- Enroll in programs
- View enrolled programs with persistent state after refresh
- See success, error, and loading states

Built with **React, Axios, and modern CSS**.

---

---

## Setup Instructions

1. Navigate to frontend folder:
cd frontend1

2.Install dependencies:
npm install

3.Start the frontend development server:
npm start
Opens in http://localhost:3000
Ensure backend is running at http://localhost:5000

4.API Integration
All API requests are handled via Axios in src/services/api.js:
fetchPrograms()             → GET /api/programs
enrollProgram(data)         → POST /api/enroll
fetchEnrollments(userId)    → GET /api/enroll/:userId
