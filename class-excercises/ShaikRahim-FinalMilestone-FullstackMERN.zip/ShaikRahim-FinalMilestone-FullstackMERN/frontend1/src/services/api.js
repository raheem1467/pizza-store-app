import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5000/api"
});

export const fetchPrograms = () => API.get("/programs");

export const enrollProgram = (data) => API.post("/enroll", data);

export const fetchEnrollments = (userId) =>
  API.get(`/enroll/${userId}`);