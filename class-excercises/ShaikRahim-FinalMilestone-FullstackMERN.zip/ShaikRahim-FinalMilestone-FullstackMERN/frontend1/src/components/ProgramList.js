import React, { useEffect, useState } from "react";
import { fetchPrograms, enrollProgram, fetchEnrollments } from "../services/api";
import "../styles/program.css";

const ProgramList = () => {

  const userId = "USR101";

  const [programs, setPrograms] = useState([]);
  const [enrolledPrograms, setEnrolledPrograms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {

    try {

      const programRes = await fetchPrograms();
      setPrograms(programRes.data.data);

      const enrollRes = await fetchEnrollments(userId);

      const enrolledIds = enrollRes.data.data.map(
        (e) => e.programId
      );

      setEnrolledPrograms(enrolledIds);

    } catch (error) {

      console.error(error);

    } finally {

      setLoading(false);

    }

  };

  const handleEnroll = async (programId) => {

    try {

      await enrollProgram({
        userId,
        programId
      });

      setMessage("Enrollment successful");

      setEnrolledPrograms([...enrolledPrograms, programId]);

    } catch (err) {

      if (err.response?.data?.message === "Already enrolled") {
        setMessage("Already enrolled in this program");
      } else {
        setMessage("Server error occurred");
      }

    }

  };

  if (loading) return <h2>Loading programs...</h2>;

  return (

    <div className="container">

      <h1>FitTrack Programs</h1>

      {message && <p className="message">{message}</p>}

      <div className="program-grid">

        {programs.map((program) => {

          const isEnrolled = enrolledPrograms.includes(program.programId);

          return (

            <div className="card" key={program.programId}>

              <h3>{program.name}</h3>

              <p><b>Category:</b> {program.category}</p>
              <p><b>Level:</b> {program.level}</p>
              <p><b>Price:</b> ₹{program.price}</p>

              <button
                disabled={isEnrolled}
                onClick={() => handleEnroll(program.programId)}
              >

                {isEnrolled ? "Enrolled" : "Enroll"}

              </button>

            </div>

          );

        })}

      </div>

      <h2>My Enrolled Programs</h2>

      {enrolledPrograms.length === 0 ? (
        <p>No programs enrolled yet</p>
      ) : (

        <ul>
          {enrolledPrograms.map((id) => (
            <li key={id}>{id}</li>
          ))}
        </ul>

      )}

    </div>

  );

};

export default ProgramList;