const express = require("express");
const router = express.Router();

const Enrollment = require("../models/Enrollment");
const Program = require("../models/Program");

router.post("/", async(req,res,next)=>{

  try{

    const {userId, programId} = req.body;

    if(!userId){
      return res.status(400).json({
        success:false,
        message:"userId required",
        data:null
      });
    }

    const program = await Program.findOne({programId});

    if(!program){
      return res.status(404).json({
        success:false,
        message:"Program not found",
        data:null
      });
    }

    const exists = await Enrollment.findOne({userId,programId});

    if(exists){
      return res.status(400).json({
        success:false,
        message:"Already enrolled",
        data:null
      });
    }

    const enrollment = new Enrollment({userId,programId});
    await enrollment.save();

    res.status(201).json({
      success:true,
      message:"Enrollment successful",
      data:enrollment
    });

  }catch(err){
    next(err);
  }

});

router.get("/:userId", async (req, res, next) => {

  try {

    const { userId } = req.params;

    const enrollments = await Enrollment.find({ userId });

    res.status(200).json({
      success: true,
      message: "Enrollments fetched",
      data: enrollments
    });

  } catch (err) {
    next(err);
  }

});

module.exports = router;