const express = require("express");
const router = express.Router();
const Program = require("../models/Program");
const {validateProgram} = require("../middleware/validate");

router.post("/", validateProgram, async(req,res,next)=>{

  try{

    const program = new Program(req.body);
    await program.save();

    res.status(201).json({
      success:true,
      message:"Program created",
      data:program
    });

  }catch(err){
    next(err);
  }

});


router.get("/", async(req,res,next)=>{

  try{

    const programs = await Program.find();

    res.status(200).json({
      success:true,
      message:"Programs fetched",
      data:programs
    });

  }catch(err){
    next(err);
  }

});

module.exports = router;