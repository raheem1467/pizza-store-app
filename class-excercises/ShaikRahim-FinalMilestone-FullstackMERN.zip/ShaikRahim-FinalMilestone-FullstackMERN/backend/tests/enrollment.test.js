const request = require("supertest");
const mongoose = require("mongoose");
const app = require("../app");
const Program = require("../models/Program");

describe("Enrollment API", function () {

  this.timeout(10000); // increase timeout

  before(async () => {
    
    await mongoose.connect("mongodb://127.0.0.1:27017/fittrack_test");

    // insert program for testing
    await Program.create({
      programId: "FTP001",
      name: "Beginner Full Body Workout",
      category: "Strength Training",
      level: "Beginner",
      price: 1999
    });

  });

  after(async () => {
    await mongoose.connection.dropDatabase();
    await mongoose.connection.close();
  });

  it("should enroll successfully", async () => {

  const res = await request(app)
    .post("/api/enroll")
    .send({
      userId: "USR101",
      programId: "FTP001"
    });

  if (res.status !== 201) {
    throw new Error("Expected status 201");
  }

});


it("should prevent duplicate enrollment", async () => {

  const res = await request(app)
    .post("/api/enroll")
    .send({
      userId: "USR101",
      programId: "FTP001"
    });

  if (res.status !== 400) {
    throw new Error("Expected status 400 for duplicate");
  }

});

});