const Joi = require("joi");

const programSchema = Joi.object({
  programId: Joi.string().required(),
  name: Joi.string().required(),
  category: Joi.string().required(),
  level: Joi.string().valid("Beginner","Intermediate","Advanced"),
  price: Joi.number().min(0).required()
});

exports.validateProgram = (req,res,next)=>{
  
  const {error} = programSchema.validate(req.body);

  if(error){
    return res.status(400).json({
      success:false,
      message:error.details[0].message,
      data:null
    });
  }

  next();
};