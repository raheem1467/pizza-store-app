const express = require("express")
const router = express.Router()
const bcrypt = require("bcrypt")
const User = require("../models/User")
const passport = require("passport")

router.post("/register",async(req,res)=>{

const {name,email,password,role} = req.body

const hashedPassword = await bcrypt.hash(password,10)

const user = new User({
    name,
    email,
    password:hashedPassword,
    role
})

await user.save()

console.log("User saved:",user)

res.send(`Registration successful for ${name}`)

})

router.post("/login",
passport.authenticate("local",{
    successRedirect:"/dashboard",
    failureRedirect:"/login"
})
)

router.get("/dashboard",(req,res)=>{
    if(!req.isAuthenticated()){
        return res.send("Please login first")
    }

    res.send(`Welcome ${req.user.name}`)
})

module.exports = router