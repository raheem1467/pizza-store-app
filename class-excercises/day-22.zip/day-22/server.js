require("dotenv").config()

const express = require("express")
const mongoose = require("mongoose")
const bodyParser = require("body-parser")
const session = require("express-session")
const passport = require("passport")

const authRoutes = require("./routes/authRoutes")
const adminRoutes = require("./routes/adminRoutes")

require("./config/passport")(passport)

const app = express()

app.use(bodyParser.urlencoded({extended:true}))

app.use(session({
    secret:process.env.SESSION_SECRET,
    resave:false,
    saveUninitialized:false
}))

app.use(passport.initialize())
app.use(passport.session())

mongoose.connect(process.env.MONGO_URI)
.then(()=>console.log("MongoDB Connected"))

app.use(authRoutes)
app.use(adminRoutes)

app.get("/register",(req,res)=>{
    res.sendFile(__dirname + "/views/register.html")
})

app.get("/login",(req,res)=>{
    res.sendFile(__dirname + "/views/login.html")
})

app.listen(process.env.PORT,()=>{
    console.log("Server running on port",process.env.PORT)
})