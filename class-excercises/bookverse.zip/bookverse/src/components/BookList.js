import React, { useState } from "react";
import BookCard from "./BookCard";
import "./BookStyles.css";

function BookList() {

  const [viewMode, setViewMode] = useState("grid");
  const [searchTerm, setSearchTerm] = useState("");

  const books = [
    { id: 1, title: "Atomic Habits", author: "James Clear", price: 499 },
    { id: 2, title: "The Alchemist", author: "Paulo Coelho", price: 399 },
    { id: 3, title: "Clean Code", author: "Robert C. Martin", price: 699 },
    { id: 4, title: "Rich Dad Poor Dad", author: "Robert Kiyosaki", price: 450 },
    { id: 5, title: "Deep Work", author: "Cal Newport", price: 550 }
  ];

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container">

      <h1>📚 BookVerse – Featured Books</h1>

      {/* Search (Controlled Component) */}
      <input
        type="text"
        placeholder="Search books..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="search-box"
      />

      {/* Toggle Buttons */}
      <div className="button-group">
        <button onClick={() => setViewMode("grid")}>Grid View</button>
        <button onClick={() => setViewMode("list")}>List View</button>
      </div>

      {/* Book Display */}
      <div className={`book-list ${viewMode}`}>
        {filteredBooks.length > 0 ? (
          filteredBooks.map(book => (
            <BookCard
              key={book.id}
              title={book.title}
              author={book.author}
              price={book.price}
              viewMode={viewMode}
            />
          ))
        ) : (
          <p>No books found.</p>
        )}
      </div>

    </div>
  );
}

export default BookList;
