// ============================================
// USER STORY 1: Database Setup and Data Modeling
// ============================================
// MongoDB Shell Script - BookVerse Database Setup
// Duration: Setup Phase
// Focus: NoSQL structure, MongoDB data modeling

// Step 1: Create/Switch to BookVerseDB
use('BookVerseDB');

// Step 2: Drop existing collections (if any)
db.Authors.drop();
db.Books.drop();
db.Users.drop();

// ============================================
// CREATE AUTHORS COLLECTION with Schema
// ============================================
console.log("Creating Authors collection...");
db.Authors.insertMany([
  {
    _id: "auth001",
    name: "J.K. Rowling",
    nationality: "British",
    birthYear: 1965
  },
  {
    _id: "auth002",
    name: "George R.R. Martin",
    nationality: "American",
    birthYear: 1948
  },
  {
    _id: "auth003",
    name: "Isaac Asimov",
    nationality: "American",
    birthYear: 1920
  },
  {
    _id: "auth004",
    name: "J.R.R. Tolkien",
    nationality: "British",
    birthYear: 1892
  }
]);
console.log("✓ Authors collection created with 4 documents");

// ============================================
// CREATE USERS COLLECTION
// ============================================
console.log("Creating Users collection...");
db.Users.insertMany([
  {
    _id: "user001",
    name: "Alice Johnson",
    email: "alice.johnson@email.com",
    joinDate: new Date("2024-09-15")
  },
  {
    _id: "user002",
    name: "Bob Smith",
    email: "bob.smith@email.com",
    joinDate: new Date("2024-10-20")
  },
  {
    _id: "user003",
    name: "Carol Davis",
    email: "carol.davis@email.com",
    joinDate: new Date("2025-08-10")
  },
  {
    _id: "user004",
    name: "David Wilson",
    email: "david.wilson@email.com",
    joinDate: new Date("2025-12-01")
  }
]);
console.log("✓ Users collection created with 4 documents");

// ============================================
// CREATE BOOKS COLLECTION with Embedded Ratings
// ============================================
console.log("Creating Books collection...");
db.Books.insertMany([
  {
    _id: "book001",
    title: "Harry Potter and the Sorcerer's Stone",
    genre: "Fantasy",
    publicationYear: 1998,
    authorId: "auth001",
    ratings: [
      { user: "user001", score: 5, comment: "Magical and captivating!" },
      { user: "user002", score: 4, comment: "Great introduction to the series" }
    ]
  },
  {
    _id: "book002",
    title: "A Game of Thrones",
    genre: "Fantasy",
    publicationYear: 1996,
    authorId: "auth002",
    ratings: [
      { user: "user001", score: 5, comment: "Complex and gripping!" },
      { user: "user003", score: 4, comment: "Intricate plot lines" }
    ]
  },
  {
    _id: "book003",
    title: "Foundation",
    genre: "Science Fiction",
    publicationYear: 1951,
    authorId: "auth003",
    ratings: [
      { user: "user002", score: 5, comment: "Classic sci-fi masterpiece" },
      { user: "user004", score: 4, comment: "Visionary and innovative" }
    ]
  },
  {
    _id: "book004",
    title: "I, Robot",
    genre: "Science Fiction",
    publicationYear: 1950,
    authorId: "auth003",
    ratings: [
      { user: "user001", score: 4, comment: "Great stories about AI" },
      { user: "user003", score: 5, comment: "Revolutionary concepts" }
    ]
  },
  {
    _id: "book005",
    title: "The Hobbit",
    genre: "Fantasy",
    publicationYear: 1937,
    authorId: "auth004",
    ratings: [
      { user: "user002", score: 5, comment: "Adventure and wonder!" },
      { user: "user004", score: 5, comment: "Timeless classic" }
    ]
  },
  {
    _id: "book006",
    title: "The Fellowship of the Ring",
    genre: "Fantasy",
    publicationYear: 2001,
    authorId: "auth004",
    ratings: [
      { user: "user001", score: 5, comment: "Epic and immersive" }
    ]
  }
]);
console.log("✓ Books collection created with 6 documents");

// ============================================
// VERIFY COLLECTIONS
// ============================================
console.log("\n========== COLLECTIONS SUMMARY ==========");
console.log("Authors Count: " + db.Authors.countDocuments());
console.log("Books Count: " + db.Books.countDocuments());
console.log("Users Count: " + db.Users.countDocuments());

// Display sample documents
console.log("\n========== SAMPLE DOCUMENTS ==========");
console.log("\n--- Authors Sample ---");
db.Authors.findOne();

console.log("\n--- Books Sample ---");
db.Books.findOne();

console.log("\n--- Users Sample ---");
db.Users.findOne();

console.log("\n✓ Database setup completed successfully!");
console.log("✓ All collections created with sample data");
