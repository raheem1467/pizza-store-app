// ============================================
// BONUS CHALLENGE: Node.js & Mongoose Integration
// ============================================
// This script demonstrates using Mongoose ORM to interact with BookVerse database
// 
// Prerequisites:
// npm install mongoose
//
// Usage:
// node mongoose_integration.js

const mongoose = require('mongoose');

// ============================================
// MONGODB CONNECTION
// ============================================
const MONGODB_URI = 'mongodb://localhost:27017/BookVerseDB';
// For MongoDB Atlas, use:
// const MONGODB_URI = 'mongodb+srv://username:password@cluster.mongodb.net/BookVerseDB';

console.log('Connecting to MongoDB...');

mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('✓ Connected to MongoDB'))
.catch(err => {
  console.error('✗ Connection failed:', err.message);
  process.exit(1);
});

// ============================================
// SCHEMA DEFINITIONS
// ============================================

// Author Schema
const authorSchema = new mongoose.Schema({
  _id: String,
  name: String,
  nationality: String,
  birthYear: Number
}, { collection: 'Authors' });

// Rating Sub-schema (embedded in Books)
const ratingSchema = new mongoose.Schema({
  user: String,
  score: Number,
  comment: String
}, { _id: false });

// Book Schema
const bookSchema = new mongoose.Schema({
  _id: String,
  title: String,
  genre: String,
  publicationYear: Number,
  authorId: String,
  ratings: [ratingSchema]
}, { collection: 'Books' });

// User Schema
const userSchema = new mongoose.Schema({
  _id: String,
  name: String,
  email: String,
  joinDate: Date
}, { collection: 'Users' });

// ============================================
// MODEL DEFINITIONS
// ============================================
const Author = mongoose.model('Author', authorSchema);
const Book = mongoose.model('Book', bookSchema);
const User = mongoose.model('User', userSchema);

// ============================================
// ASYNC OPERATIONS
// ============================================
async function runOperations() {
  try {
    console.log('\n========== MONGOOSE OPERATIONS ==========\n');

    // ============================================
    // 1. COUNT DOCUMENTS
    // ============================================
    console.log('--- 1. Document Counts ---');
    const authorCount = await Author.countDocuments();
    const bookCount = await Book.countDocuments();
    const userCount = await User.countDocuments();

    console.log(`Authors: ${authorCount}`);
    console.log(`Books: ${bookCount}`);
    console.log(`Users: ${userCount}`);

    // ============================================
    // 2. CREATE NEW DOCUMENTS
    // ============================================
    console.log('\n--- 2. Create New Documents ---');
    
    const newAuthor = new Author({
      _id: 'auth005',
      name: 'Stephen King',
      nationality: 'American',
      birthYear: 1947
    });
    
    await newAuthor.save();
    console.log('✓ New author created');

    const newBook = new Book({
      _id: 'book008',
      title: 'The Stand',
      genre: 'Horror',
      publicationYear: 1978,
      authorId: 'auth005',
      ratings: [
        { user: 'user001', score: 5, comment: 'Masterpiece of horror fiction' }
      ]
    });
    
    await newBook.save();
    console.log('✓ New book created');

    // ============================================
    // 3. READ DOCUMENTS
    // ============================================
    console.log('\n--- 3. Read Documents ---');
    
    // Find all Science Fiction books
    const sfBooks = await Book.find({ genre: 'Science Fiction' });
    console.log(`Science Fiction books: ${sfBooks.length}`);
    sfBooks.forEach(book => {
      console.log(`  - ${book.title}`);
    });

    // Find books by specific author
    const asimovBooks = await Book.find({ authorId: 'auth003' });
    console.log(`\nIsaac Asimov's books: ${asimovBooks.length}`);
    asimovBooks.forEach(book => {
      console.log(`  - ${book.title} (${book.publicationYear})`);
    });

    // ============================================
    // 4. UPDATE DOCUMENTS
    // ============================================
    console.log('\n--- 4. Update Documents ---');
    
    // Update using updateOne
    const updateResult = await Book.updateOne(
      { _id: 'book008' },
      { $set: { genre: 'Supernatural Thriller' } }
    );
    console.log(`✓ Updated document(s): ${updateResult.modifiedCount}`);

    // Add new rating to a book
    const pushResult = await Book.updateOne(
      { _id: 'book001' },
      {
        $push: {
          ratings: {
            user: 'user007',
            score: 5,
            comment: 'Magical world brought to life!'
          }
        }
      }
    );
    console.log(`✓ Added new rating to Harry Potter`);

    // ============================================
    // 5. ADVANCED QUERIES
    // ============================================
    console.log('\n--- 5. Advanced Queries ---');

    // Books published after 1950
    const recentBooks = await Book.find({ publicationYear: { $gt: 1950 } });
    console.log(`\nBooks published after 1950: ${recentBooks.length}`);
    recentBooks.forEach(book => {
      console.log(`  - ${book.title} (${book.publicationYear})`);
    });

    // Users joined within date range
    const sixMonthsAgo = new Date('2025-09-03');
    const currentDate = new Date('2026-03-03');
    
    const recentUsers = await User.find({
      joinDate: { $gte: sixMonthsAgo, $lte: currentDate }
    });
    console.log(`\nUsers joined in last 6 months: ${recentUsers.length}`);
    recentUsers.forEach(user => {
      console.log(`  - ${user.name} (joined: ${user.joinDate.toDateString()})`);
    });

    // ============================================
    // 6. AGGREGATION PIPELINE
    // ============================================
    console.log('\n--- 6. Aggregation Pipeline ---');

    // Books with rating statistics
    const booksWithStats = await Book.aggregate([
      {
        $project: {
          title: 1,
          genre: 1,
          totalRatings: { $size: { $ifNull: ['$ratings', []] } },
          averageRating: {
            $cond: [
              { $gt: [{ $size: { $ifNull: ['$ratings', []] } }, 0] },
              { $avg: '$ratings.score' },
              0
            ]
          }
        }
      },
      {
        $sort: { totalRatings: -1, averageRating: -1 }
      },
      {
        $limit: 3
      }
    ]);

    console.log('\nTop 3 Most-Rated Books:');
    booksWithStats.forEach((book, index) => {
      console.log(`${index + 1}. ${book.title}`);
      console.log(`   Genre: ${book.genre}`);
      console.log(`   Avg Rating: ${book.averageRating.toFixed(2)}/5`);
      console.log(`   Total Ratings: ${book.totalRatings}`);
    });

    // ============================================
    // 7. DELETE DOCUMENTS
    // ============================================
    console.log('\n--- 7. Delete Operations ---');
    
    // Delete the newly created author and book for cleanup
    const deleteAuthor = await Author.deleteOne({ _id: 'auth005' });
    console.log(`Deleted author documents: ${deleteAuthor.deletedCount}`);

    const deleteBook = await Book.deleteOne({ _id: 'book008' });
    console.log(`Deleted book documents: ${deleteBook.deletedCount}`);

    // ============================================
    // 8. FINAL STATISTICS
    // ============================================
    console.log('\n--- 8. Final Statistics ---');
    const finalAuthorCount = await Author.countDocuments();
    const finalBookCount = await Book.countDocuments();
    const finalUserCount = await User.countDocuments();

    console.log(`Final Authors: ${finalAuthorCount}`);
    console.log(`Final Books: ${finalBookCount}`);
    console.log(`Final Users: ${finalUserCount}`);

    console.log('\n✓ All Mongoose operations completed successfully!');

  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    // Close connection
    await mongoose.connection.close();
    console.log('\n✓ MongoDB connection closed');
    process.exit(0);
  }
}

// Run the operations
runOperations();

// ============================================
// ADDITIONAL MONGOOSE EXAMPLES (Reference)
// ============================================
/*
// Example: Using findById
const book = await Book.findById('book001');

// Example: Using select
const books = await Book.find().select('title genre');

// Example: Using lean for better performance
const fastBooks = await Book.find().lean();

// Example: Using populate (would work if we set up references differently)
const populatedBooks = await Book.find().populate('authorId');

// Example: Custom methods
authorSchema.methods.getFullInfo = function() {
  return `${this.name} from ${this.nationality}`;
};

// Example: Using $or operator
const mixedBooks = await Book.find({
  $or: [
    { genre: 'Fantasy' },
    { publicationYear: { $lt: 1950 } }
  ]
});

// Example: Bulk operations
const bulkOps = [
  { insertOne: { document: newBook } },
  { updateOne: { filter: { _id: 'book001' }, update: { $set: { genre: 'Updated' } } } },
  { deleteOne: { filter: { _id: 'book099' } } }
];
await Book.collection.bulkWrite(bulkOps);

// Example: Transactions (requires replica set)
const session = await mongoose.startSession();
session.startTransaction();
try {
  await Author.create([newAuthor], { session });
  await Book.create([newBook], { session });
  await session.commitTransaction();
} catch (error) {
  await session.abortTransaction();
  throw error;
}
*/
