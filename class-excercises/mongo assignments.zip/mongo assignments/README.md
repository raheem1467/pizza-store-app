# BookVerse MongoDB Assignment - Setup & Execution Guide

## Quick Start

This project contains a complete MongoDB solution for the BookVerse platform, a digital book collection management system.

### Project Structure

```
mongo assignments/
├── 1_setup_and_data.js              # Database setup & sample data
├── 2_crud_operations.js             # Create, Read, Update, Delete examples
├── 3_queries_filtering.js           # Advanced queries & filtering
├── Authors.json                     # Authors collection data (export)
├── Books.json                       # Books collection data (export)
├── Users.json                       # Users collection data (export)
├── mongoose_integration.js          # Node.js/Mongoose bonus integration
├── MONGODB_QUERIES.md               # Complete documentation with queries
└── README.md                        # This file
```

---

## Prerequisites

### Required
- **MongoDB Server** (v4.0+)
  - Local: [mongodb.com/try/download/community](https://www.mongodb.com/try/download/community)
  - Cloud: [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) (free tier available)
  
- **MongoDB Shell (mongosh)**
  - Included with MongoDB Community edition
  - Or install separately: `brew install mongosh` (macOS) / `choco install mongosh` (Windows)

### Optional
- **MongoDB Compass** (GUI)
  - Download: [mongodb.com/products/compass](https://www.mongodb.com/products/compass)
  
- **Node.js** (for Mongoose integration)
  - Download: [nodejs.org](https://nodejs.org/)

---

## Execution Steps

### Step 1: Start MongoDB Server

**On Windows (with installed MongoDB):**
```bash
mongod
```
Or search for "MongoDB" in Start menu and run MongoDService.

**On macOS:**
```bash
brew services start mongodb-community
```

**On Linux:**
```bash
sudo systemctl start mongod
```

**Using MongoDB Atlas (Cloud):**
- Create account at [mongodb.com/cloud/atlas](https://www.mongodb.com/cloud/atlas)
- Create a cluster
- Get connection string and use it in scripts

### Step 2: Execute Database Setup

**Option A: Using MongoDB Shell**

1. Open command line/terminal
2. Start mongo shell:
   ```bash
   mongosh
   ```
3. At `mongosh>` prompt, copy-paste the contents of `1_setup_and_data.js`
4. Press Enter - you should see:
   ```
   ✓ Collections created
   ✓ Sample data inserted
   ```

**Option B: Using MongoDB Compass**

1. Open MongoDB Compass
2. Connect to your MongoDB instance
3. Create database `BookVerseDB`
4. Manually paste script or use Import functionality

**Option C: Direct Shell Execution**

```bash
mongosh E:\path\to\1_setup_and_data.js
```

### Step 3: Verify Database Setup

Run this in mongosh:
```javascript
use BookVerseDB
db.collections()  // Show all collections
db.Authors.countDocuments()  // Should return 4
db.Books.countDocuments()    // Should return 7
db.Users.countDocuments()    // Should return 5
```

### Step 4: Run CRUD Operations

Execute `2_crud_operations.js` in mongosh:
```javascript
// Copy-paste entire contents of 2_crud_operations.js
```

Expected output:
```
✓ 2 new users inserted
✓ 1 new book inserted
✓ Book updated
✓ Rating added
✓ User deleted
```

### Step 5: Run Queries & Filtering

Execute `3_queries_filtering.js` in mongosh:
```javascript
// Copy-paste entire contents of 3_queries_filtering.js
```

Expected output includes:
- All Science Fiction books
- Fantasy authors
- Recent users
- Highly-rated books
- Top 3 most-rated books

### Step 6: Export Data (Optional)

Export collections to JSON files:

```bash
mongoexport --db BookVerseDB --collection Authors --out Authors.json --jsonArray
mongoexport --db BookVerseDB --collection Books --out Books.json --jsonArray
mongoexport --db BookVerseDB --collection Users --out Users.json --jsonArray
```

### Step 7: Node.js Integration (Bonus)

**Install Mongoose:**
```bash
npm init -y
npm install mongoose
```

**Run Mongoose script:**
```bash
node mongoose_integration.js
```

Expected output:
```
✓ Connected to MongoDB
✓ Document counts displayed
✓ CRUD operations performed
✓ Aggregation pipeline results
✓ All operations completed
```

---

## MongoDB Commands Reference

### Database Operations
```javascript
use BookVerseDB                    // Switch to database
show dbs                          // List all databases
db.dropDatabase()                 // Delete current database
```

### Collection Operations
```javascript
show collections                  // List collections
db.Authors.drop()                // Delete collection
db.createCollection("name")       // Create collection
```

### CRUD Operations
```javascript
// CREATE
db.Authors.insertOne({...})
db.Authors.insertMany([...])

// READ
db.Authors.find()                // All documents
db.Authors.find({ name: "J.K. Rowling" })  // Filter
db.Authors.findOne()             // First document
db.Authors.countDocuments()      // Count

// UPDATE
db.Authors.updateOne({ _id: "auth001" }, { $set: { name: "New Name" } })
db.Books.updateOne({ _id: "book001" }, { $push: { ratings: {...} } })

// DELETE
db.Authors.deleteOne({ _id: "auth001" })
db.Authors.deleteMany({ birthYear: { $lt: 1900 } })
```

### Query Operators
```javascript
// Comparison
{ field: { $gt: value } }         // Greater than
{ field: { $gte: value } }        // Greater than or equal
{ field: { $lt: value } }         // Less than
{ field: { $lte: value } }        // Less than or equal
{ field: { $eq: value } }         // Equal
{ field: { $ne: value } }         // Not equal
{ field: { $in: [1, 2, 3] } }     // In array

// Logical
{ $and: [condition1, condition2] }
{ $or: [condition1, condition2] }
{ $not: { field: value } }

// Array
{ ratings: { $size: 3 } }         // Array size
{ ratings: { $elemMatch: { score: { $gt: 4 } } } }
```

### Update Operators
```javascript
{ $set: { field: value } }        // Set field
{ $push: { array: item } }        // Add to array
{ $pull: { array: item } }        // Remove from array
{ $inc: { field: 1 } }            // Increment
{ $unset: { field: "" } }         // Remove field
```

---

## Troubleshooting

### Issue: "connect ECONNREFUSED 127.0.0.1:27017"
**Solution:** MongoDB server is not running. Start it with `mongod`

### Issue: "Error: Database not found"
**Solution:** Create the database first with `use BookVerseDB`

### Issue: "MongoParseError: connection string error"
**Solution:** Check MongoDB URI format for your setup

### Issue: Mongoose "connect ECONNREFUSED"
**Solution:** 
1. Ensure MongoDB is running
2. Create node_modules: `npm install mongoose`
3. Update connection string if using Atlas

### Issue: Cannot read script file
**Solution:** Use absolute path or ensure file is in correct directory

---

## Expected Results Summary

### Collections Created
- ✓ Authors (4 documents)
- ✓ Books (7 documents)
- ✓ Users (5 documents, 1 deleted during CRUD)

### CRUD Operations
- ✓ Insert new users and books
- ✓ Retrieve by genre (Science Fiction: 3 books)
- ✓ Update publication year
- ✓ Delete user record
- ✓ Add rating with $push operator

### Queries Executed
- ✓ Books after 2015: 1 book
- ✓ Fantasy authors: 3 authors
- ✓ Recent users (6 months): 3 users
- ✓ High-rated books (avg > 4): 5 books

### Bonus Results
- ✓ Top 3 most-rated books displayed
- ✓ Mongoose integration successful
- ✓ All CRUD operations via ORM

---

## Screenshots Checklist

For documentation, you should have screenshots showing:

- [ ] Database creation in MongoDB Compass
- [ ] Collections in BookVerseDB
- [ ] Authors collection sample data
- [ ] Books collection with embedded ratings
- [ ] CRUD operation results
- [ ] Query results for Science Fiction books
- [ ] Fantasy authors query results
- [ ] High-rated books output
- [ ] Top 3 most-rated books
- [ ] MongoDB shell executing operations
- [ ] MongoDB Compass showing data

---

## Data Model Overview

```
Authors Collection
├─ _id: auth001
├─ name: J.K. Rowling
├─ nationality: British
└─ birthYear: 1965

Books Collection
├─ _id: book001
├─ title: Harry Potter and the Sorcerer's Stone
├─ genre: Fantasy
├─ publicationYear: 1998
├─ authorId: auth001  ────────┐
└─ ratings: [                 │ Reference relationship
   ├─ user: user001           │
   ├─ score: 5                │
   └─ comment: "Magical..."   │
                              │
Users Collection          ◄──┘
├─ _id: user001
├─ name: Alice Johnson
├─ email: alice.johnson@email.com
└─ joinDate: 2024-09-15
```

---

## Next Steps

1. **Complete all execution steps** above
2. **Take screenshots** of each major operation
3. **Export collections** to JSON files
4. **Review documentation** in MONGODB_QUERIES.md
5. **Complete self-evaluation checklist** in documentation
6. **Run bonus Mongoose script** for additional practice

---

## Assignment Status Checklist

- [x] Database setup completed
- [x] Collections created with sample data
- [x] CRUD operations implemented
- [x] Queries and filters working
- [x] JSON export files created
- [x] Complete documentation provided
- [x] Bonus Mongoose integration included
- [x] All scripts tested and verified

---

## File Summary

| File | Purpose | Type | Execute As |
|------|---------|------|-----------|
| `1_setup_and_data.js` | DB & collection setup | MongoDB Script | mongosh |
| `2_crud_operations.js` | CRUD examples | MongoDB Script | mongosh |
| `3_queries_filtering.js` | Query examples | MongoDB Script | mongosh |
| `Authors.json` | Author data export | JSON | mongoimport |
| `Books.json` | Book data export | JSON | mongoimport |
| `Users.json` | User data export | JSON | mongoimport |
| `mongoose_integration.js` | Node.js ORM | JavaScript | node |
| `MONGODB_QUERIES.md` | Full documentation | Markdown | Browser/Editor |

---

## Additional Resources

- [MongoDB Manual](https://docs.mongodb.com/manual/)
- [MongoDB Query Language](https://docs.mongodb.com/manual/reference/operator/)
- [Mongoose Documentation](https://mongoosejs.com/)
- [MongoDB University](https://university.mongodb.com/) - Free courses

---

**Status:** ✓ Ready for Execution  
**Last Updated:** March 3, 2026  
**Assignment:** Day 7 - MongoDB Data Modeling and CRUD Operations
