// ============================================
// USER STORY 3: Querying and Filtering Data
// ============================================
// MongoDB Shell Script - Advanced Queries and Filters
// Focus: Query filters, conditional operators, nested field access

use('BookVerseDB');

console.log("========== QUERYING AND FILTERING DATA ==========\n");

// ============================================
// QUERY 1: Retrieve all books published after 2015
// ============================================
console.log("--- QUERY 1: Books published after 2015 ---");
console.log("Filter: { publicationYear: { $gt: 2015 } }\n");

const booksAfter2015 = db.Books.find({ publicationYear: { $gt: 2015 } }).toArray();
if (booksAfter2015.length > 0) {
  booksAfter2015.forEach((book, index) => {
    console.log(`${index + 1}. "${book.title}" (${book.publicationYear}) - ${book.genre}`);
  });
  console.log(`\nTotal books found: ${booksAfter2015.length}`);
} else {
  console.log("No books found published after 2015");
}

// ============================================
// QUERY 2: Find authors who have written books in "Fantasy" genre
// ============================================
console.log("\n--- QUERY 2: Authors who wrote Fantasy books ---");
console.log("Approach: Aggregate books by genre, then match with authors\n");

const fantasyBooks = db.Books.find({ genre: "Fantasy" }).toArray();
const authorIds = new Set(fantasyBooks.map(book => book.authorId));

console.log("Fantasy Books Authors:");
const fantasyAuthors = db.Authors.find({ _id: { $in: Array.from(authorIds) } }).toArray();
fantasyAuthors.forEach((author, index) => {
  const booksByAuthor = fantasyBooks.filter(b => b.authorId === author._id);
  console.log(`${index + 1}. ${author.name} (${author.nationality})`);
  console.log(`   - Books: ${booksByAuthor.map(b => b.title).join(", ")}`);
});

console.log(`\nTotal authors with Fantasy books: ${fantasyAuthors.length}`);

// ============================================
// QUERY 3: Retrieve all users who joined within the last 6 months
// ============================================
console.log("\n--- QUERY 3: Users joined in the last 6 months ---");

// Current date for this scenario: March 3, 2026
const currentDate = new Date("2026-03-03");
const sixMonthsAgo = new Date(currentDate);
sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6); // September 3, 2025

console.log(`Current Date: ${currentDate.toDateString()}`);
console.log(`Last 6 Months From: ${sixMonthsAgo.toDateString()}\n`);

const recentUsers = db.Users.find({ joinDate: { $gte: sixMonthsAgo, $lte: currentDate } }).toArray();

recentUsers.forEach((user, index) => {
  const joinDateStr = user.joinDate.toDateString();
  console.log(`${index + 1}. ${user.name} (${user.email}) - Joined: ${joinDateStr}`);
});

console.log(`\nTotal users joined in last 6 months: ${recentUsers.length}`);

// ============================================
// QUERY 4: Find books with an average rating greater than 4
// ============================================
console.log("\n--- QUERY 4: Books with average rating > 4 ---\n");

const allBooks = db.Books.find({}).toArray();
const booksWithHighRatings = allBooks.filter(book => {
  if (book.ratings && book.ratings.length > 0) {
    const avgRating = book.ratings.reduce((sum, r) => sum + r.score, 0) / book.ratings.length;
    return avgRating > 4;
  }
  return false;
});

booksWithHighRatings.forEach((book, index) => {
  const avgRating = (book.ratings.reduce((sum, r) => sum + r.score, 0) / book.ratings.length).toFixed(2);
  const ratingCount = book.ratings.length;
  console.log(`${index + 1}. "${book.title}"`);
  console.log(`   - Average Rating: ${avgRating}/5 (${ratingCount} ratings)`);
  book.ratings.forEach(rating => {
    console.log(`     * ${rating.user}: ${rating.score}/5 - "${rating.comment}"`);
  });
  console.log("");
});

console.log(`Total books with avg rating > 4: ${booksWithHighRatings.length}`);

// ============================================
// BONUS QUERY 1: Top 3 Most-Rated Books
// ============================================
console.log("\n========== BONUS: TOP 3 MOST-RATED BOOKS ==========\n");

const booksWithStats = allBooks.map(book => {
  const avgRating = book.ratings && book.ratings.length > 0 
    ? book.ratings.reduce((sum, r) => sum + r.score, 0) / book.ratings.length 
    : 0;
  return {
    _id: book._id,
    title: book.title,
    genre: book.genre,
    totalRatings: book.ratings ? book.ratings.length : 0,
    averageRating: avgRating
  };
});

// Sort by number of ratings (descending) and then by average rating
const topBooks = booksWithStats
  .sort((a, b) => {
    if (b.totalRatings !== a.totalRatings) {
      return b.totalRatings - a.totalRatings;
    }
    return b.averageRating - a.averageRating;
  })
  .slice(0, 3);

topBooks.forEach((book, index) => {
  console.log(`${index + 1}. "${book.title}" (${book.genre})`);
  console.log(`   - Average Rating: ${book.averageRating.toFixed(2)}/5`);
  console.log(`   - Total Ratings: ${book.totalRatings}`);
  console.log("");
});

// ============================================
// BONUS QUERY 2: Books by Genre (with counts)
// ============================================
console.log("========== BONUS: BOOKS BY GENRE ==========\n");

const booksByGenre = {};
allBooks.forEach(book => {
  if (!booksByGenre[book.genre]) {
    booksByGenre[book.genre] = [];
  }
  booksByGenre[book.genre].push(book.title);
});

Object.keys(booksByGenre).sort().forEach(genre => {
  console.log(`${genre}: ${booksByGenre[genre].length} book(s)`);
  booksByGenre[genre].forEach(title => {
    console.log(`  - ${title}`);
  });
  console.log("");
});

console.log("✓ All queries executed successfully!");
