// ============================================
// USER STORY 2: CRUD Operations
// ============================================
// MongoDB Shell Script - CRUD Operations on BookVerse
// Focus: CRUD operations, update modifiers ($push, $set)

use('BookVerseDB');

console.log("========== CRUD OPERATIONS DEMO ==========\n");

// ============================================
// C - CREATE: Insert new users and books
// ============================================
console.log("--- 1. CREATE: Insert New Records ---");

console.log("Inserting new users...");
db.Users.insertMany([
  {
    _id: "user005",
    name: "Emma Thompson",
    email: "emma.thompson@email.com",
    joinDate: new Date("2026-01-15")
  },
  {
    _id: "user006",
    name: "Frank Miller",
    email: "frank.miller@email.com",
    joinDate: new Date("2026-02-20")
  }
]);
console.log("✓ 2 new users inserted");

console.log("\nInserting new books...");
db.Books.insertOne({
  _id: "book007",
  title: "Neuromancer",
  genre: "Science Fiction",
  publicationYear: 1984,
  authorId: "auth003",
  ratings: [
    { user: "user005", score: 4, comment: "Pioneering cyberpunk novel" }
  ]
});
console.log("✓ 1 new book inserted");

// ============================================
// R - READ: Retrieve various data
// ============================================
console.log("\n--- 2. READ: Retrieve Data ---");

console.log("\nRetrieving all books of genre 'Science Fiction':");
db.Books.find({ genre: "Science Fiction" }).pretty();

// ============================================
// U - UPDATE: Update book details
// ============================================
console.log("\n--- 3. UPDATE: Modify Records ---");

console.log("Updating publicationYear for 'Neuromancer'...");
db.Books.updateOne(
  { _id: "book007" },
  { $set: { publicationYear: 1984 } }
);
console.log("✓ Book updated");

console.log("\nAdding a new rating to 'Harry Potter' using $push...");
db.Books.updateOne(
  { _id: "book001" },
  {
    $push: {
      ratings: {
        user: "user005",
        score: 5,
        comment: "Still enchanting after all these years!"
      }
    }
  }
);
console.log("✓ New rating added to book");

console.log("\nVerifying rating was added:");
db.Books.findOne(
  { _id: "book001" },
  { ratings: 1 }
).ratings.forEach((rating) => {
  console.log(`  - ${rating.user}: ${rating.score}/5 - "${rating.comment}"`);
});

// ============================================
// D - DELETE: Remove a record
// ============================================
console.log("\n--- 4. DELETE: Remove Records ---");

console.log("Deleting user 'David Wilson' (user004)...");
const deleteResult = db.Users.deleteOne({ _id: "user004" });
if (deleteResult.deletedCount > 0) {
  console.log("✓ User deleted successfully");
} else {
  console.log("✗ No user found to delete");
}

// ============================================
// ADDITIONAL CRUD EXAMPLES
// ============================================
console.log("\n--- 5. ADDITIONAL CRUD OPERATIONS ---");

console.log("\nUpdate: Adding a rating to 'A Game of Thrones'...");
db.Books.updateOne(
  { _id: "book002" },
  {
    $push: {
      ratings: {
        user: "user006",
        score: 5,
        comment: "Couldn't put it down!"
      }
    }
  }
);
console.log("✓ Rating added");

console.log("\nRetrieve: Finding all books by Isaac Asimov...");
const asimovBooks = db.Books.find({ authorId: "auth003" }).toArray();
asimovBooks.forEach((book) => {
  console.log(`  - ${book.title} (${book.publicationYear}) - ${book.genre}`);
});

console.log("\nUpdate: Changing Emma Thompson's email...");
db.Users.updateOne(
  { _id: "user005" },
  { $set: { email: "emmat@newdomain.com" } }
);
console.log("✓ User email updated");

// ============================================
// SUMMARY STATISTICS
// ============================================
console.log("\n========== POST-CRUD STATISTICS ==========");
console.log("Total Authors: " + db.Authors.countDocuments());
console.log("Total Books: " + db.Books.countDocuments());
console.log("Total Users: " + db.Users.countDocuments());

console.log("\n✓ All CRUD operations completed successfully!");
