# MongoDB Queries Quick Reference - BookVerse Project

## Database & Collection Setup

### Create Database
```javascript
use BookVerseDB
```

### Drop Collections
```javascript
db.Authors.drop()
db.Books.drop()
db.Users.drop()
```

### Create Collections
```javascript
db.createCollection("Authors")
db.createCollection("Books")
db.createCollection("Users")
```

---

## INSERT (Create)

### Insert Single Document
```javascript
db.Authors.insertOne({
  _id: "auth001",
  name: "J.K. Rowling",
  nationality: "British",
  birthYear: 1965
})
```

### Insert Multiple Documents
```javascript
db.Authors.insertMany([
  { _id: "auth001", name: "J.K. Rowling", nationality: "British", birthYear: 1965 },
  { _id: "auth002", name: "George R.R. Martin", nationality: "American", birthYear: 1948 }
])
```

### Insert Users
```javascript
db.Users.insertMany([
  {
    _id: "user001",
    name: "Alice Johnson",
    email: "alice.johnson@email.com",
    joinDate: new Date("2024-09-15")
  }
])
```

### Insert Books
```javascript
db.Books.insertMany([
  {
    _id: "book001",
    title: "Harry Potter and the Sorcerer's Stone",
    genre: "Fantasy",
    publicationYear: 1998,
    authorId: "auth001",
    ratings: [
      { user: "user001", score: 5, comment: "Magical!" }
    ]
  }
])
```

---

## FIND (Read)

### Find All Documents
```javascript
db.Authors.find()
db.Books.find()
db.Users.find()
```

### Find with Filter (Equality)
```javascript
db.Books.find({ genre: "Science Fiction" })
db.Authors.find({ nationality: "British" })
db.Users.find({ name: "Alice Johnson" })
```

### Find with Comparison Operators
```javascript
// Greater than
db.Books.find({ publicationYear: { $gt: 2015 } })

// Greater than or equal
db.Books.find({ publicationYear: { $gte: 2000 } })

// Less than
db.Books.find({ publicationYear: { $lt: 1950 } })

// Less than or equal
db.Books.find({ publicationYear: { $lte: 2000 } })

// Not equal
db.Books.find({ genre: { $ne: "Fantasy" } })
```

### Find with IN Operator
```javascript
db.Authors.find({ _id: { $in: ["auth001", "auth002", "auth003"] } })
```

### Find with Logical Operators
```javascript
// OR
db.Books.find({ $or: [{ genre: "Fantasy" }, { genre: "Science Fiction" }] })

// AND (default - can be implicit)
db.Books.find({ 
  $and: [
    { genre: "Fantasy" },
    { publicationYear: { $gt: 1990 } }
  ]
})
```

### Find One Document
```javascript
db.Authors.findOne({ name: "J.K. Rowling" })
db.Books.findOne({ _id: "book001" })
```

### Find with Projection (Select Specific Fields)
```javascript
// Only show title and genre
db.Books.find({}, { title: 1, genre: 1, _id: 0 })

// Show all except ratings
db.Books.find({}, { ratings: 0 })
```

### Find with Sort
```javascript
// Sort ascending
db.Books.find().sort({ publicationYear: 1 })

// Sort descending
db.Books.find().sort({ publicationYear: -1 })

// Sort by multiple fields
db.Books.find().sort({ genre: 1, publicationYear: -1 })
```

### Find with Limit & Skip
```javascript
// Get first 5 books
db.Books.find().limit(5)

// Skip first 5, get next 5
db.Books.find().skip(5).limit(5)
```

### Find Date Range
```javascript
const startDate = new Date("2025-09-03");
const endDate = new Date("2026-03-03");

db.Users.find({
  joinDate: { $gte: startDate, $lte: endDate }
})
```

---

## UPDATE

### Update Single Field
```javascript
db.Books.updateOne(
  { _id: "book001" },
  { $set: { publicationYear: 1998 } }
)
```

### Update Multiple Fields
```javascript
db.Authors.updateOne(
  { _id: "auth001" },
  { 
    $set: { 
      name: "Joanne Rowling",
      nationality: "British"
    }
  }
)
```

### Push to Array (Add Item)
```javascript
db.Books.updateOne(
  { _id: "book001" },
  {
    $push: {
      ratings: {
        user: "user005",
        score: 5,
        comment: "Amazing!"
      }
    }
  }
)
```

### Push Multiple Items to Array
```javascript
db.Books.updateOne(
  { _id: "book001" },
  {
    $push: {
      ratings: {
        $each: [
          { user: "user005", score: 5, comment: "Great!" },
          { user: "user006", score: 4, comment: "Good!" }
        ]
      }
    }
  }
)
```

### Increment Field
```javascript
db.Books.updateOne(
  { _id: "book001" },
  { $inc: { viewCount: 1 } }
)
```

### Update Multiple Documents
```javascript
db.Books.updateMany(
  { genre: "Science Fiction" },
  { $set: { category: "Sci-Fi" } }
)
```

### Update with Unset (Remove Field)
```javascript
db.Books.updateOne(
  { _id: "book001" },
  { $unset: { tempField: "" } }
)
```

### Replace Entire Document
```javascript
db.Authors.replaceOne(
  { _id: "auth001" },
  {
    _id: "auth001",
    name: "Joanne Kathleen Rowling",
    nationality: "British",
    birthYear: 1965,
    biography: "..."
  }
)
```

---

## DELETE

### Delete Single Document
```javascript
db.Users.deleteOne({ _id: "user004" })
```

### Delete Multiple Documents
```javascript
db.Books.deleteMany({ publicationYear: { $lt: 1900 } })
```

### Delete All Documents in Collection
```javascript
db.Authors.deleteMany({})
```

---

## COUNT

### Count All Documents
```javascript
db.Authors.countDocuments()
db.Books.countDocuments()
db.Users.countDocuments()
```

### Count with Filter
```javascript
db.Books.countDocuments({ genre: "Fantasy" })
db.Users.countDocuments({ joinDate: { $gte: new Date("2025-09-03") } })
```

---

## AGGREGATION

### Count by Genre
```javascript
db.Books.aggregate([
  {
    $group: {
      _id: "$genre",
      count: { $sum: 1 }
    }
  }
])
```

### Average Rating by Book
```javascript
db.Books.aggregate([
  {
    $project: {
      title: 1,
      avgRating: { $avg: "$ratings.score" }
    }
  }
])
```

### Top N Books by Rating Count
```javascript
db.Books.aggregate([
  {
    $project: {
      title: 1,
      ratingCount: { $size: "$ratings" }
    }
  },
  { $sort: { ratingCount: -1 } },
  { $limit: 3 }
])
```

### Books with Author Details (Lookup)
```javascript
db.Books.aggregate([
  {
    $lookup: {
      from: "Authors",
      localField: "authorId",
      foreignField: "_id",
      as: "author"
    }
  },
  { $unwind: "$author" }
])
```

---

## USER STORY 1 - SETUP QUERIES

### Create Authors Collection
```javascript
db.Authors.insertMany([
  { _id: "auth001", name: "J.K. Rowling", nationality: "British", birthYear: 1965 },
  { _id: "auth002", name: "George R.R. Martin", nationality: "American", birthYear: 1948 },
  { _id: "auth003", name: "Isaac Asimov", nationality: "American", birthYear: 1920 },
  { _id: "auth004", name: "J.R.R. Tolkien", nationality: "British", birthYear: 1892 }
])
```

### Create Users Collection
```javascript
db.Users.insertMany([
  { _id: "user001", name: "Alice Johnson", email: "alice.johnson@email.com", joinDate: new Date("2024-09-15") },
  { _id: "user002", name: "Bob Smith", email: "bob.smith@email.com", joinDate: new Date("2024-10-20") },
  { _id: "user003", name: "Carol Davis", email: "carol.davis@email.com", joinDate: new Date("2025-08-10") }
])
```

### Create Books Collection
```javascript
db.Books.insertMany([
  {
    _id: "book001",
    title: "Harry Potter and the Sorcerer's Stone",
    genre: "Fantasy",
    publicationYear: 1998,
    authorId: "auth001",
    ratings: [
      { user: "user001", score: 5, comment: "Magical!" },
      { user: "user002", score: 4, comment: "Great!" }
    ]
  }
  // ... more books
])
```

---

## USER STORY 2 - CRUD QUERIES

### Read: All Science Fiction Books
```javascript
db.Books.find({ genre: "Science Fiction" })
```

### Update: Change Publication Year
```javascript
db.Books.updateOne(
  { _id: "book007" },
  { $set: { publicationYear: 1984 } }
)
```

### Delete: Remove User
```javascript
db.Users.deleteOne({ _id: "user004" })
```

### Update: Add Rating
```javascript
db.Books.updateOne(
  { _id: "book001" },
  {
    $push: {
      ratings: {
        user: "user005",
        score: 5,
        comment: "Still enchanting!"
      }
    }
  }
)
```

---

## USER STORY 3 - QUERY & FILTER QUERIES

### Query 1: Books After 2015
```javascript
db.Books.find({ publicationYear: { $gt: 2015 } })
```

### Query 2: Fantasy Authors
```javascript
const fantasyBooks = db.Books.find({ genre: "Fantasy" }).toArray();
const authorIds = fantasyBooks.map(b => b.authorId);
db.Authors.find({ _id: { $in: authorIds } })
```

### Query 3: Users Last 6 Months
```javascript
const sixMonthsAgo = new Date();
sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

db.Users.find({
  joinDate: { $gte: sixMonthsAgo }
})
```

### Query 4: Books with Avg Rating > 4
```javascript
db.Books.aggregate([
  {
    $project: {
      title: 1,
      genre: 1,
      avgRating: { $avg: "$ratings.score" }
    }
  },
  {
    $match: { avgRating: { $gt: 4 } }
  }
])
```

---

## BONUS - TOP 3 BOOKS

### Top 3 Most-Rated Books
```javascript
db.Books.aggregate([
  {
    $project: {
      title: 1,
      genre: 1,
      totalRatings: { $size: { $ifNull: ["$ratings", []] } },
      avgRating: {
        $cond: [
          { $gt: [{ $size: { $ifNull: ["$ratings", []] } }, 0] },
          { $avg: "$ratings.score" },
          0
        ]
      }
    }
  },
  { $sort: { totalRatings: -1, avgRating: -1 } },
  { $limit: 3 }
])
```

---

## IMPORT/EXPORT

### Export Collections to JSON
```bash
mongoexport --db BookVerseDB --collection Authors --out Authors.json --jsonArray
mongoexport --db BookVerseDB --collection Books --out Books.json --jsonArray
mongoexport --db BookVerseDB --collection Users --out Users.json --jsonArray
```

### Import Collections from JSON
```bash
mongoimport --db BookVerseDB --collection Authors --file Authors.json --jsonArray
mongoimport --db BookVerseDB --collection Books --file Books.json --jsonArray
mongoimport --db BookVerseDB --collection Users --file Users.json --jsonArray
```

---

## UTILITY QUERIES

### Show Databases
```javascript
show dbs
```

### Show Collections in Current DB
```javascript
show collections
```

### Get Collection Statistics
```javascript
db.Authors.stats()
db.Books.stats()
```

### Get Document Size
```javascript
Object.bsonsize(db.Authors.findOne())
```

### List All Indexes
```javascript
db.Books.getIndexes()
```

### Create Index
```javascript
db.Books.createIndex({ genre: 1 })
db.Books.createIndex({ publicationYear: -1 })
db.Books.createIndex({ genre: 1, publicationYear: -1 })
```

### Drop Index
```javascript
db.Books.dropIndex("genre_1")
```

---

## VALIDATION

### Check if Collection Exists
```javascript
db.getCollectionNames().includes("Authors")
```

### Validate Data Integrity
```javascript
// Check for books without authors
db.Books.find({ authorId: { $exists: false } })

// Check for orphaned ratings
db.Books.find({ ratings: 0 })

// Check for duplicate IDs
db.Authors.aggregate([
  { $group: { _id: "$_id", count: { $sum: 1 } } },
  { $match: { count: { $gt: 1 } } }
])
```

---

## TIPS & BEST PRACTICES

1. **Use `pretty()`** for readable output: `db.Books.find().pretty()`
2. **Use projections** to reduce data transfer: `db.Books.find({}, { title: 1 })`
3. **Always specify `_id`** or MongoDB auto-generates: `_id: ObjectId()`
4. **Use indexes** for frequently queried fields
5. **Normalize vs Denormalize**: Use references for 1-to-many, embed for small arrays
6. **Batch operations** for better performance: `insertMany()`, `updateMany()`
7. **Use aggregation** for complex queries over multiple operations
8. **Set up validation** on collection creation for data integrity

---

**Quick Reference Summary:**
- **Basic CRUD**: insert, find, updateOne, deleteOne
- **Operators**: $gt, $gte, $lt, $lte, $in, $set, $push, $inc
- **Arrays**: $push, $pull, $size, $elemMatch
- **Aggregation**: $project, $match, $group, $sort, $limit
- **Admin**: show dbs, show collections, db.stats()

Save this guide for quick lookups during development!
