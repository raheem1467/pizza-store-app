# Node.js Assessment 3 – Express.js Challenges

This folder contains solutions for Day 19 Express.js fundamentals, routing, and middleware challenges.

## 📁 Folder layout
```
nodejs-assessment3/
├── server.js              # main Express app
├── routes/
│   └── books.js           # modular /books routes
├── package.json           # dependencies & start script
├── README.md              # this instructions file
└── screenshots/           # place your terminal/browser captures
```

## 🔧 Setup
1. Open a terminal in this folder:
   ```bash
   cd C:\Users\rahee\OneDrive\Desktop\assessmet\sql_assessment\nodejs-assessment3
   ```
2. Install Express:
   ```bash
   npm install
   ```

## 🚀 Running and testing
Start the server:
```bash
npm start
```
(It listens on port 4000.)

### Challenge 1 – Basic Express server
- Visit `http://localhost:4000/` → should display **Welcome to Express Server** (take screenshot `ch1-home.png`).
- Bonus: `http://localhost:4000/status` → JSON `{ "server": "running", "uptime": "OK" }` (`ch1-status.png`).

### Challenge 2 – Routing and query parameters
- `http://localhost:4000/products?name=Laptop` → JSON `{ "query": "Laptop" }` (`ch2-query.png`).
- `http://localhost:4000/products` → text **Please provide a product name** (`ch2-noquery.png`).

### Challenge 3 – Middleware logging
- Every request prints `[timestamp] [METHOD] URL` in console (timestamp bonus).
- Hit multiple routes above and capture console screenshot `ch3-logs.png` showing logs.

### Challenge 4 – REST API (CRUD for books)
Use Postman/curl or browser for GET.
- `GET /books` → returns list of books (`ch4-get.png`).
- `POST /books` with JSON body `{ "title": "New", "author": "Me" }` → adds book (`ch4-post.png`).
- `PUT /books/1` to update (body e.g. `{ "title": "1984 revised" }`) (`ch4-put.png`).
- `DELETE /books/2` (`ch4-delete.png`).
  - Bonus: validation rejects missing title/author (try `POST {}` and screenshot `ch4-valid.png`).

### Challenge 5 – Modular routing & error handling
- `/books` routes live in `routes/books.js` (modularized).
- Invalid path (e.g. `/foo`) returns `{ error: "Route not found" }` (`ch5-404.png`).
- Server logs internal errors if triggered (bonus global handler).

## 📌 Full‑marks checklist
- Express installed, imported, server runs on port 4000 ✅
- GET routes working, bonus JSON status and product query ✅
- Custom logging middleware with timestamp applied to all requests ✅
- CRUD routes implemented with route params, validation bonus ✅
- Routes moved to separate module and imported via `app.use('/books', bookRouter)` ✅
- 404 and error-handling middleware included ✅
- Screenshots instructions for each step – use the `screenshots` folder

Feel free to stop the server with `Ctrl+C` when done. Good luck with your submission! 🎯