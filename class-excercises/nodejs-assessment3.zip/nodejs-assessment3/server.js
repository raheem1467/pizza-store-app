// server.js
// Day 19 – Express.js fundamentals, routing & middleware

const express = require('express');
const bookRouter = require('./routes/books');

const app = express();
const port = 4000;

// body parser for JSON
app.use(express.json());

// custom logging middleware with timestamp
app.use((req, res, next) => {
  const ts = new Date().toISOString();
  console.log(`[${ts}] [${req.method}] ${req.url}`);
  next();
});

// basic routes
app.get('/', (req, res) => {
  res.send('Welcome to Express Server');
});

app.get('/status', (req, res) => {
  res.json({ server: 'running', uptime: 'OK' });
});

// products route with query param
app.get('/products', (req, res) => {
  const name = req.query.name;
  if (name) {
    // bonus: return json
    res.json({ query: name });
  } else {
    res.send('Please provide a product name');
  }
});

// mount books router
app.use('/books', bookRouter);

// 404 handler
app.use((req, res, next) => {
  res.status(404).json({ error: 'Route not found' });
});

// global error handler
app.use((err, req, res, next) => {
  console.error('Internal error:', err);
  res.status(500).json({ error: 'Internal Server Error' });
});

app.listen(port, () => {
  console.log(`Express server listening on http://localhost:${port}`);
});