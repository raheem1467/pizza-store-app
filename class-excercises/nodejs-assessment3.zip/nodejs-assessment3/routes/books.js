// routes/books.js

const express = require('express');
const router = express.Router();

let books = [
  { id: 1, title: "1984", author: "Orwell" },
  { id: 2, title: "The Alchemist", author: "Coelho" }
];

// GET /books - return all
router.get('/', (req, res) => {
  res.json(books);
});

// POST /books - add new with validation
router.post('/', (req, res) => {
  const { title, author } = req.body;
  if (!title || !author) {
    return res.status(400).json({ error: 'title and author required' });
  }
  const id = books.length ? books[books.length - 1].id + 1 : 1;
  const newBook = { id, title, author };
  books.push(newBook);
  res.status(201).json(newBook);
});

// PUT /books/:id - update
router.put('/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const { title, author } = req.body;
  const book = books.find(b => b.id === id);
  if (!book) return res.status(404).json({ error: 'not found' });
  if (title) book.title = title;
  if (author) book.author = author;
  res.json(book);
});

// DELETE /books/:id
router.delete('/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const idx = books.findIndex(b => b.id === id);
  if (idx === -1) return res.status(404).json({ error: 'not found' });
  const deleted = books.splice(idx, 1)[0];
  res.json(deleted);
});

module.exports = router;