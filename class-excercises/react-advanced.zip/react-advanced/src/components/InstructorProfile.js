export default function InstructorProfile() {
  return (
    <div className="card p-3 mt-3">
      <h3>Instructor: John Doe</h3>
      <p>10+ years React experience</p>
    </div>
  );
}
