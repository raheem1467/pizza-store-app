export default function CourseDetails() {
  return (
    <div className="card p-3 mt-3">
      <h3>React Advanced Course</h3>
      <p>This course covers lazy loading, portals, error boundaries.</p>
    </div>
  );
}
