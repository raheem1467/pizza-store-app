import React from "react";

const StatsCard = React.memo(({ title, value, lastUpdated }) => {
  console.log(`${title} rendered`);

  return (
    <div className="card p-3 m-2">
      <h4>{title}</h4>
      <h2>{value}</h2>
      <small>Last updated: {lastUpdated}</small>
    </div>
  );
});

export default StatsCard;
