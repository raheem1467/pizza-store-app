export default function ProductCard() {
  throw new Error("Product crashed!");
}
