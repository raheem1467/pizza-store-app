import React from "react";
import ReactDOM from "react-dom";
import { motion } from "framer-motion";

export default function Modal({ isOpen, onClose }) {
  if (!isOpen) return null;

  return ReactDOM.createPortal(
    <motion.div
      className="modal-backdrop show d-flex justify-content-center align-items-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      style={{ backgroundColor: "rgba(0,0,0,0.5)" }}
    >
      <div className="bg-white p-4 rounded">
        <h4>This is a Portal Modal</h4>
        <button className="btn btn-danger" onClick={onClose}>
          Close
        </button>
      </div>
    </motion.div>,
    document.getElementById("portal-root")
  );
}
