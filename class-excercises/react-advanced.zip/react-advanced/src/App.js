import React, { useState, Suspense } from "react";
import StatsCard from "./components/StatsCard";
import ErrorBoundary from "./components/ErrorBoundary";
import ProductCard from "./components/ProductCard";
import Modal from "./components/Modal";

// 🔥 Lazy Loaded Components
const CourseDetails = React.lazy(() =>
  import("./components/CourseDetails")
);
const InstructorProfile = React.lazy(() =>
  import("./components/InstructorProfile")
);

function App() {
  // Lazy loading state
  const [showCourse, setShowCourse] = useState(false);
  const [showInstructor, setShowInstructor] = useState(false);

  // Pure component state
  const [users, setUsers] = useState(100);
  const [sales, setSales] = useState(200);

  // Portal modal state
  const [open, setOpen] = useState(false);

  return (
    <div className="container mt-4">
      <h1 className="text-center mb-4">🚀 React Advanced Concepts App</h1>

      {/* =============================== */}
      {/* 🔥 Challenge 1: Lazy Loading */}
      {/* =============================== */}
      <h3>Lazy Loading Demo</h3>

      <button
        className="btn btn-primary m-2"
        onClick={() => setShowCourse(true)}
      >
        View Course Details
      </button>

      <button
        className="btn btn-success m-2"
        onClick={() => setShowInstructor(true)}
      >
        View Instructor Profile
      </button>

      <Suspense
        fallback={
          <div className="spinner-border text-primary mt-3" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        }
      >
        {showCourse && <CourseDetails />}
        {showInstructor && <InstructorProfile />}
      </Suspense>

      <hr />

      {/* =============================== */}
      {/* 🔥 Challenge 2: Pure Component */}
      {/* =============================== */}
      <h3>Dashboard Stats (React.memo)</h3>

      <button
        className="btn btn-warning m-2"
        onClick={() => setUsers(users + 1)}
      >
        Update Users
      </button>

      <button
        className="btn btn-danger m-2"
        onClick={() => setSales(sales + 1)}
      >
        Update Sales
      </button>

      <div className="d-flex">
        <StatsCard
          title="Users"
          value={users}
          lastUpdated={new Date().toLocaleTimeString()}
        />
        <StatsCard
          title="Sales"
          value={sales}
          lastUpdated={new Date().toLocaleTimeString()}
        />
      </div>

      <hr />

      {/* =============================== */}
      {/* 🔥 Challenge 3: Error Boundary */}
      {/* =============================== */}
      <h3>Error Boundary Demo</h3>

      <ErrorBoundary>
        <ProductCard />
      </ErrorBoundary>

      <hr />

      {/* =============================== */}
      {/* 🔥 Challenge 4: React Portal */}
      {/* =============================== */}
      <h3>Portal Modal Demo</h3>

      <button
        className="btn btn-dark"
        onClick={() => setOpen(true)}
      >
        Open Modal
      </button>

      <Modal isOpen={open} onClose={() => setOpen(false)} />
    </div>
  );
}

export default App;
