import React from "react";
import BookForm from "./components/BookForm";
import BookList from "./components/BookList";

function App() {
  return (
    <div className="container mt-4">
      <h1>📚 Book Verse</h1>
      <BookForm />
      <BookList />
    </div>
  );
}

export default App;
