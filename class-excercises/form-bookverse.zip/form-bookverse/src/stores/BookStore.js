import AppDispatcher from "../dispatcher/AppDispatcher";

class BookStore {
  constructor() {
    this.books = [];
    this.listeners = [];
    
    AppDispatcher.register(this.handleActions.bind(this));
  }

  handleActions(action) {
    switch (action.type) {
      case "ADD_BOOK":
        this.books.push(action.payload);
        this.emitChange();
        break;
      default:
        break;
    }
  }

  getBooks() {
    return this.books;
  }

  emitChange() {
    this.listeners.forEach((cb) => cb());
  }

  addChangeListener(callback) {
    this.listeners.push(callback);
  }

  removeChangeListener(callback) {
    this.listeners = this.listeners.filter((cb) => cb !== callback);
  }
}

export default new BookStore();
