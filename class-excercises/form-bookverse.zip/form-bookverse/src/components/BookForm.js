import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { addBook } from "../actions/bookActions";

export default function BookForm() {
  const initialValues = { title: "", author: "", price: "" };

  const validationSchema = Yup.object({
    title: Yup.string().required("Required"),
    author: Yup.string().required("Required"),
    price: Yup.number()
      .typeError("Must be a number")
      .required("Required"),
  });

  const onSubmit = (values, { resetForm }) => {
    addBook(values);
    resetForm();
  };

  return (
    <div className="card p-3 mb-3">
      <h3>Add New Book</h3>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={onSubmit}
      >
        <Form>
          <div className="mb-2">
            <label>Title:</label>
            <Field name="title" className="form-control" />
            <ErrorMessage
              name="title"
              component="div"
              className="text-danger"
            />
          </div>

          <div className="mb-2">
            <label>Author:</label>
            <Field name="author" className="form-control" />
            <ErrorMessage
              name="author"
              component="div"
              className="text-danger"
            />
          </div>

          <div className="mb-2">
            <label>Price:</label>
            <Field name="price" className="form-control" />
            <ErrorMessage
              name="price"
              component="div"
              className="text-danger"
            />
          </div>

          <button type="submit" className="btn btn-primary">
            Add Book
          </button>
        </Form>
      </Formik>
    </div>
  );
}
