import React, { useEffect, useState } from "react";
import BookStore from "../stores/BookStore";

export default function BookList() {
  const [books, setBooks] = useState(BookStore.getBooks());

  const updateBooks = () => {
    setBooks([...BookStore.getBooks()]);
  };

  useEffect(() => {
    BookStore.addChangeListener(updateBooks);
    return () => BookStore.removeChangeListener(updateBooks);
  }, []);

  if (books.length === 0) return <p>No books added yet.</p>;

  return (
    <div className="card p-3">
      <h3>Book List</h3>
      <ul className="list-group">
        {books.map((book, index) => (
          <li key={index} className="list-group-item">
            <strong>{book.title}</strong> by {book.author} — ${book.price}
          </li>
        ))}
      </ul>
    </div>
  );
}
