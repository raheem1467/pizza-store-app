class Dispatcher {
  constructor() {
    this.callbacks = [];
  }

  register(callback) {
    this.callbacks.push(callback);
  }

  dispatch(action) {
    for (const cb of this.callbacks) {
      cb(action);
    }
  }
}

export default new Dispatcher();
