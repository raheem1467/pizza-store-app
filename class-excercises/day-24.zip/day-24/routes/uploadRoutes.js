const express = require("express")
const router = express.Router()
const upload = require("../middleware/upload")

router.post("/upload", upload.single("file"), (req,res)=>{

res.send(`File uploaded successfully: ${req.file.originalname}`)

})

module.exports = router