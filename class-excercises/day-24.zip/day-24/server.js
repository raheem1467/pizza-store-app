const express = require("express")
const http = require("http")
const { Server } = require("socket.io")

const uploadRoutes = require("./routes/uploadRoutes")

const app = express()

const server = http.createServer(app)

const io = new Server(server)

app.use(express.json())

// upload routes
app.use(uploadRoutes)

// serve uploaded files
app.use("/materials", express.static("uploads"))

// serve chat page
app.use(express.static("public"))

io.on("connection",(socket)=>{

console.log("User connected")

socket.on("chatMessage",(msg)=>{

io.emit("chatMessage",msg)

})

socket.on("disconnect",()=>{
console.log("User disconnected")
})

})

server.listen(5009,()=>{
console.log("Server running on port 5000")
})