Prerequisites

Node.js & npm

Installation

Navigate to the frontend folder:

cd frontend

Install dependencies:

npm install
Running the Frontend

Start the React app:

npm start

App will open in your browser at:

http://localhost:3000
Usage

Admin Actions:

Use the Admin panel or API to create courses (POST /api/courses).

Learner Actions:

Browse courses in the frontend.

Click Enroll Now to enroll in a course.

View enrolled courses in the “Enrolled Courses” section.

Duplicate enrollments are prevented automatically