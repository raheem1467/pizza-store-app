// import React, { useEffect, useState } from "react";
// import { getCourses, enrollCourse } from "../services/api";

// const CourseList = () => {

//   const [courses, setCourses] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");
//   const [enrolledCourses, setEnrolledCourses] = useState([]);

//   useEffect(() => {

//     const fetchCourses = async () => {
//       try {

//         const res = await getCourses();
//         setCourses(res.data.data);

//       } catch (err) {

//         setError("Failed to load courses");

//       } finally {

//         setLoading(false);

//       }
//     };

//     fetchCourses();

//   }, []);

//   const handleEnroll = async (courseId) => {

//     try {

//       const res = await enrollCourse({
//         userId: "user1",
//         courseId
//       });

//       alert("Enrollment Successful");

//       setEnrolledCourses([
//         ...enrolledCourses,
//         courseId
//       ]);

//     } catch (err) {

//       if (err.response?.data?.message === "Already enrolled") {

//         alert("Duplicate Enrollment");

//       } else {

//         alert("Network Error");

//       }

//     }

//   };

//   if (loading) return <h3>Loading...</h3>;

//   if (error) return <h3>{error}</h3>;

//   return (
//     <div>

//       <h2>Course Catalog</h2>

//       {courses.map(course => (

//         <div key={course.courseId}
//         style={{
//           border:"1px solid gray",
//           padding:"10px",
//           margin:"10px"
//         }}>

//           <h3>{course.title}</h3>
//           <p>Category: {course.category}</p>
//           <p>Price: ${course.price}</p>

//           <button
//             onClick={() =>
//               handleEnroll(course.courseId)
//             }
//           >
//             Enroll Now
//           </button>

//         </div>

//       ))}

//       <h2>Enrolled Courses</h2>

//       <ul>
//         {enrolledCourses.map((c,i)=>(
//           <li key={i}>{c}</li>
//         ))}
//       </ul>

//     </div>
//   );
// };

// export default CourseList;




// import React, { useEffect, useState } from "react";
// import { getCourses, enrollCourse } from "../services/api";

// const CourseList = () => {

//   const [courses, setCourses] = useState([]);
//   const [enrolledCourses, setEnrolledCourses] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");

//   // Fetch courses
//   useEffect(() => {
//     const fetchCourses = async () => {
//       try {

//         const res = await getCourses();
//         setCourses(res.data.data);

//       } catch (err) {

//         setError("Failed to load courses");

//       } finally {

//         setLoading(false);

//       }
//     };

//     fetchCourses();
//   }, []);

//   // Enroll function
//   const handleEnroll = async (courseId) => {

//     try {

//       await enrollCourse({
//         userId: "user1",
//         courseId
//       });

//       alert("Enrollment Successful");

//       setEnrolledCourses(prev => {
//         if (!prev.includes(courseId)) {
//           return [...prev, courseId];
//         }
//         return prev;
//       });

//     } catch (err) {

//       if (err.response?.data?.message === "Already enrolled") {

//         alert("Already enrolled");

//         setEnrolledCourses(prev => {
//           if (!prev.includes(courseId)) {
//             return [...prev, courseId];
//           }
//           return prev;
//         });

//       } else {

//         alert("Network Error");

//       }

//     }

//   };

//   // Loading UI
//   if (loading) return <h3>Loading courses...</h3>;

//   // Error UI
//   if (error) return <h3>{error}</h3>;

//   return (
//     <div style={{ padding: "20px", fontFamily: "Arial" }}>

//       <h2>Course Catalog</h2>

//       {courses.length === 0 && <p>No courses available</p>}

//       {courses.map(course => (

//         <div
//           key={course.courseId}
//           style={{
//             border: "1px solid #ccc",
//             borderRadius: "6px",
//             padding: "15px",
//             marginBottom: "10px",
//             width: "350px"
//           }}
//         >

//           <h3>{course.title}</h3>

//           <p>
//             <strong>Category:</strong> {course.category}
//           </p>

//           <p>
//             <strong>Price:</strong> ${course.price}
//           </p>

//           <button
//             onClick={() => handleEnroll(course.courseId)}
//             style={{
//               padding: "8px 12px",
//               cursor: "pointer"
//             }}
//           >
//             Enroll Now
//           </button>

//         </div>

//       ))}

//       <hr />

//       <h2>Enrolled Courses</h2>

//       {enrolledCourses.length === 0 ? (

//         <p>No courses enrolled yet</p>

//       ) : (

//         <ul>

//           {enrolledCourses.map(id => {

//             const course = courses.find(c => c.courseId === id);

//             return (
//               <li key={id}>
//                 {course ? course.title : id}
//               </li>
//             );

//           })}

//         </ul>

//       )}

//     </div>
//   );
// };

// export default CourseList;

import React, { useEffect, useState } from "react";
import { getCourses, enrollCourse } from "../services/api";
import "bootstrap/dist/css/bootstrap.min.css";

const CourseList = () => {
  const [courses, setCourses] = useState([]);
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Fetch courses
  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const res = await getCourses();
        setCourses(res.data.data);
      } catch (err) {
        setError("Failed to load courses");
      } finally {
        setLoading(false);
      }
    };
    fetchCourses();
  }, []);

  // Enroll function
  const handleEnroll = async (courseId) => {
    try {
      await enrollCourse({ userId: "user1", courseId });
      alert("Enrollment Successful");
      setEnrolledCourses((prev) => {
        if (!prev.includes(courseId)) return [...prev, courseId];
        return prev;
      });
    } catch (err) {
      if (err.response?.data?.message === "Already enrolled") {
        alert("Already enrolled");
        setEnrolledCourses((prev) => {
          if (!prev.includes(courseId)) return [...prev, courseId];
          return prev;
        });
      } else {
        alert("Network Error");
      }
    }
  };

  if (loading) return <div className="text-center mt-5"><h3>Loading courses...</h3></div>;
  if (error) return <div className="text-center mt-5"><h3>{error}</h3></div>;

  return (
    <div className="container my-5">
      <h1 className="mb-4 text-center">SmartLearn Course Catalog</h1>

      <div className="row">
        {courses.length === 0 && <p className="text-center">No courses available</p>}

        {courses.map((course) => {
          const isEnrolled = enrolledCourses.includes(course.courseId);

          return (
            <div className="col-md-4 mb-4" key={course.courseId}>
              <div
                className={`card h-100 shadow-sm ${isEnrolled ? "border-success" : ""}`}
              >
                <div className="card-body d-flex flex-column">
                  <h5 className="card-title">{course.title}</h5>
                  <p className="card-text"><strong>Category:</strong> {course.category}</p>
                  <p className="card-text"><strong>Price:</strong> ${course.price}</p>

                  {isEnrolled ? (
                    <button className="btn btn-success mt-auto" disabled>
                      Enrolled ✓
                    </button>
                  ) : (
                    <button
                      className="btn btn-primary mt-auto"
                      onClick={() => handleEnroll(course.courseId)}
                    >
                      Enroll Now
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <hr className="my-5" />

      <h2 className="mb-3">Enrolled Courses</h2>
      {enrolledCourses.length === 0 ? (
        <p>No courses enrolled yet</p>
      ) : (
        <ul className="list-group">
          {enrolledCourses.map((id) => {
            const course = courses.find((c) => c.courseId === id);
            return (
              <li key={id} className="list-group-item list-group-item-success">
                {course ? course.title : id}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
};

export default CourseList;