const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");

const courseRoutes = require("./routes/courseRoutes");
const enrollmentRoutes = require("./routes/enrollmentRoutes");
const errorHandler = require("./middleware/errorHandler");

const app = express();

connectDB();

app.use(cors());
app.use(express.json());

app.use("/api/courses", courseRoutes);
app.use("/api/enroll", enrollmentRoutes);

app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "Route not found"
  });
});

app.use(errorHandler);

app.listen(5000, () => {
  console.log("Server running on port 5000");
});

module.exports = app;