# SmartLearn Course Enrollment Portal

## Project Overview

SmartLearn is an online course enrollment portal built with the **MERN stack**:

- **Backend**: Node.js, Express.js, MongoDB  
- **Frontend**: React.js  
- **Functionality**:
  - Admin can create courses
  - Learners can browse courses
  - Learners can enroll in courses
  - Learners can view enrolled courses

---

## Backend Setup

### Prerequisites

- Node.js (v16 or higher)  
- MongoDB (local or Atlas)  
- npm

### Installation

1. Navigate to the backend folder:

```bash
cd backend

Install dependencies:

npm install

Create a .env file (optional):

PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/smartlearn
Running the Backend

Start the server:

npm run dev

Server will run at:

http://localhost:5000
Backend API Endpoints

Create Course (Admin): POST /api/courses

Fetch All Courses (Learner): GET /api/courses

Enroll in Course (Learner): POST /api/enroll

All responses are in JSON format:

{
  "success": true/false,
  "data": {},
  "message": ""
}