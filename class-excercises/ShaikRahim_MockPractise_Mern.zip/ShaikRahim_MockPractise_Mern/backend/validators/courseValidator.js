const { body } = require("express-validator");

exports.courseValidation = [
  body("courseId").notEmpty().withMessage("CourseId required"),
  body("title").notEmpty().withMessage("Title required"),
  body("category").notEmpty().withMessage("Category required"),
  body("price")
    .isFloat({ min: 0 })
    .withMessage("Price must be >= 0")
];