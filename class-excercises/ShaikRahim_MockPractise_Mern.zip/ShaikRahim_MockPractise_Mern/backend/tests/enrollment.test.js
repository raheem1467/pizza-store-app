const request = require("supertest");
const express = require("express");
const mongoose = require("mongoose");
const app = require("../server"); // your Express app

const Course = require("../models/Course");
const Enrollment = require("../models/Enrollment");

describe("SmartLearn API Tests", function () {
  // Before all tests, connect to DB
  before(async () => {
    await mongoose.connect("mongodb://127.0.0.1:27017/smartlearn_test");
  });

  // After all tests, clean up DB
  after(async () => {
    await Course.deleteMany({});
    await Enrollment.deleteMany({});
    await mongoose.connection.close();
  });

  describe("Course API", function () {
    it("should create a new course", async function () {
      const res = await request(app)
        .post("/api/courses")
        .send({
          courseId: "TEST101",
          title: "Test Course",
          category: "Testing",
          price: 50
        });
      res.should.have.status(201); // HTTP 201 Created
      res.body.should.have.property("success", true);
      res.body.data.should.have.property("courseId", "TEST101");
    });

    it("should fetch all courses", async function () {
      const res = await request(app).get("/api/courses");
      res.should.have.status(200);
      res.body.should.have.property("success", true);
      res.body.data.should.be.an("array");
    });
  });

  describe("Enrollment API", function () {
    it("should enroll a user to a course", async function () {
      const res = await request(app)
        .post("/api/enroll")
        .send({
          userId: "user1",
          courseId: "TEST101"
        });
      res.should.have.status(201);
      res.body.should.have.property("success", true);
    });

    it("should prevent duplicate enrollment", async function () {
      const res = await request(app)
        .post("/api/enroll")
        .send({
          userId: "user1",
          courseId: "TEST101"
        });
      res.should.have.status(400);
      res.body.should.have.property("success", false);
      res.body.should.have.property("message", "Already enrolled");
    });
  });
});