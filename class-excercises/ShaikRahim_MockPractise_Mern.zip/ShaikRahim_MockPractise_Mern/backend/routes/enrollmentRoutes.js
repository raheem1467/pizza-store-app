const express = require("express");
const Enrollment = require("../models/Enrollment");
const Course = require("../models/Course");

const router = express.Router();

router.post("/", async (req, res, next) => {
  try {

    const { userId, courseId } = req.body;

    if (!userId || !courseId) {
      return res.status(400).json({
        success: false,
        message: "userId and courseId required"
      });
    }

    const course = await Course.findOne({ courseId });

    if (!course) {
      return res.status(404).json({
        success: false,
        message: "Course not found"
      });
    }

    const existing = await Enrollment.findOne({ userId, courseId });

    if (existing) {
      return res.status(400).json({
        success: false,
        message: "Already enrolled"
      });
    }

    const enrollment = new Enrollment({ userId, courseId });

    await enrollment.save();

    res.status(201).json({
      success: true,
      data: enrollment,
      message: "Enrollment successful"
    });

  } catch (err) {
    next(err);
  }
});

module.exports = router;