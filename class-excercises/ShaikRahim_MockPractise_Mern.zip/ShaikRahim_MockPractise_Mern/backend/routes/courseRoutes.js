const express = require("express");
const Course = require("../models/Course");
const { validationResult } = require("express-validator");
const { courseValidation } = require("../validators/courseValidator");

const router = express.Router();

router.post("/", courseValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: errors.array()
      });
    }

    const course = new Course(req.body);
    await course.save();

    res.status(201).json({
      success: true,
      data: course,
      message: "Course created"
    });

  } catch (err) {
    next(err);
  }
});

router.get("/", async (req, res, next) => {
  try {
    const courses = await Course.find();

    res.json({
      success: true,
      data: courses,
      message: "Courses fetched"
    });

  } catch (err) {
    next(err);
  }
});

module.exports = router;