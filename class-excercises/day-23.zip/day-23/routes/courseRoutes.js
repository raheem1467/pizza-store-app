const express = require("express")
const router = express.Router()

const {
getCourses,
getCourseById,
createCourse,
updateCourse,
deleteCourse
} = require("../controllers/courseController")

const {validateCourse} = require("../middleware/validateCourse")

router.get("/",getCourses)

router.get("/:id",getCourseById)

router.post("/",validateCourse,createCourse)

router.put("/:id",validateCourse,updateCourse)

router.delete("/:id",deleteCourse)

module.exports = router