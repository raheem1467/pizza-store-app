let courses = [
{
id:1,
name:"NodeJS",
duration:"3 months"
},
{
id:2,
name:"React",
duration:"2 months"
}
]

module.exports = courses