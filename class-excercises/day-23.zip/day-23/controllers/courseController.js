const courses = require("../data/courses")

// GET all courses
exports.getCourses = (req,res)=>{
res.json(courses)
}

// GET single course
exports.getCourseById = (req,res)=>{
const course = courses.find(c=>c.id==req.params.id)

if(!course){
return res.status(404).json({error:"Course not found"})
}

res.json(course)
}

// CREATE course
exports.createCourse = (req,res)=>{
const {name,duration} = req.body

const newCourse = {
id:courses.length + 1,
name,
duration
}

courses.push(newCourse)

res.json({
message:"Course created successfully",
course:newCourse
})
}

// UPDATE course
exports.updateCourse = (req,res)=>{
const course = courses.find(c=>c.id==req.params.id)

if(!course){
return res.status(404).json({error:"Course not found"})
}

course.name = req.body.name
course.duration = req.body.duration

res.json({
message:"Course updated",
course
})
}

// DELETE course
exports.deleteCourse = (req,res)=>{

const index = courses.findIndex(c=>c.id==req.params.id)

if(index === -1){
return res.status(404).json({error:"Course not found"})
}

courses.splice(index,1)

res.json({message:"Course deleted"})
}