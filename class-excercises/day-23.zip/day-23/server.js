const express = require("express")

const courseRoutes = require("./routes/courseRoutes")
const limiter = require("./middleware/rateLimiter")
const errorHandler = require("./middleware/errorHandler")

const app = express()

app.use(express.json())

// Rate limiter
app.use(limiter)

// API Versioning
app.use("/api/v1/courses",courseRoutes)

// error handler
app.use(errorHandler)

app.listen(5050,()=>{
console.log("Server running on port 5000")
})