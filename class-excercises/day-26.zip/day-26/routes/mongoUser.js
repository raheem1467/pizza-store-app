const express = require("express");
const router = express.Router();

const User = require("../models/User");
const Enrollment = require("../models/Enrollment");

router.get("/enrollments",async(req,res)=>{

 const data = await Enrollment.find();

 res.json(data);

});

module.exports = router;