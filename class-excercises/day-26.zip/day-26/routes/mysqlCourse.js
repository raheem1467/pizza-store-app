const express = require("express");
const router = express.Router();
const db = require("../config/mysql");

router.post("/add-course",(req,res)=>{

 const {title,price} = req.body;

 const sql = "INSERT INTO courses (title,price) VALUES (?,?)";

 db.query(sql,[title,price],(err,result)=>{

    if(err) throw err;

    console.log("Course inserted successfully");

    res.json({
        message:"Course Added",
        result
    });

 });

});

module.exports = router;