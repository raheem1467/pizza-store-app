const express = require("express");
const router = express.Router();

const Instructor = require("../models/Instructor");
const Course = require("../models/Course");

router.get("/instructor-courses",async(req,res)=>{

 const data = await Instructor.findAll({
  include:Course
 });

 res.json(data);

});

module.exports = router;