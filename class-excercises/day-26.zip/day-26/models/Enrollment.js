const mongoose = require("mongoose");

const enrollmentSchema = new mongoose.Schema({
  userId: String,
  course: String
});

module.exports = mongoose.models.Enrollment || mongoose.model("Enrollment", enrollmentSchema);