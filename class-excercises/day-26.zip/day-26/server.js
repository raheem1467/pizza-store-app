const express = require("express");
require("dotenv").config();

const app = express();

app.use(express.json());

require("./config/mysql");
require("./config/mongo");

const sequelize = require("./config/sequelize");

const Instructor = require("./models/Instructor");
const Course = require("./models/Course");

Instructor.hasMany(Course);
Course.belongsTo(Instructor);

sequelize.sync();

app.use("/mysql",require("./routes/mysqlCourse"));
app.use("/mongo",require("./routes/mongoUser"));
app.use("/sequelize",require("./routes/sequelizeCourse"));

app.get("/status",(req,res)=>{
 res.send("SkillSphere DB running");
});

app.listen(process.env.PORT,()=>{
 console.log("Server running");
});