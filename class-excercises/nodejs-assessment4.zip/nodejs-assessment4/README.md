# Node.js Assessment 4 – Day 20 Routing & Middleware

This folder provides solutions for the Day 20 LMS routing exercise.

## 📁 Structure
```
nodejs-assessment4/
├── server.js            # main Express app
├── routes/
│   └── courses.js       # course routes with validation middleware
├── package.json         # dependencies and start script
├── README.md            # instructions (this file)
└── screenshots/         # save your screenshots here
```

## 🔧 Setup
1. Open terminal here:
   ```bash
   cd C:\Users\rahee\OneDrive\Desktop\assessmet\sql_assessment\nodejs-assessment4
   ```
2. Install express:
   ```bash
   npm install
   ```

## 🚀 Run & capture outputs
```bash
npm start
```
The server will run on port 4000.

### Challenge 1 – Home route
- Visit `http://localhost:4000/` → message **Welcome to SkillSphere LMS API**
- **Screenshot**: `screenshots/ch1.png`

### Challenge 2 – Dynamic routing
- Visit `http://localhost:4000/courses/101` → JSON:
  ```json
  { "id": "101", "name": "React Mastery", "duration": "6 weeks" }
  ```
- **Screenshot**: `screenshots/ch2-valid.png`

### Challenge 3 – Route middleware validation
- Visit `http://localhost:4000/courses/abc` →
  ```json
  { "error": "Invalid course ID" }
  ```
- **Screenshot**: `screenshots/ch3-invalid.png`

> Bonus: middleware is defined in `routes/courses.js` and applied before the handler.

### Additional tips
- Always start the server from the correct directory and stop with `Ctrl+C`.
- You can test using browser, curl, or Postman; JSON responses make copy‑paste easy.

### ✅ Full‑marks checklist
- Root route returns welcome message ✅
- Dynamic `/courses/:id` returning JSON ✅
- Route middleware validates numeric IDs before handling ✅
- Separate routes file used ✅
- Error response for invalid ID returned as JSON ✅

Place all collected screenshots in the `screenshots` folder before submission. Good luck! 🎯