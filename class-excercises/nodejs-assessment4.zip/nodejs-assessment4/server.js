// server.js
// Day 20 – Basic Routing & Route Middleware for SkillSphere LMS API

const express = require('express');
const courseRouter = require('./routes/courses');

const app = express();
const port = 4000;

// root welcome route
app.get('/', (req, res) => {
  res.send('Welcome to SkillSphere LMS API');
});

// mount courses router
app.use('/courses', courseRouter);

// 404 fallback
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

app.listen(port, () => console.log(`SkillSphere API running at http://localhost:${port}`));
