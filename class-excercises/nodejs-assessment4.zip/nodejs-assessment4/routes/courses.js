// routes/courses.js

const express = require('express');
const router = express.Router();

// middleware to validate numeric id
function validateCourseId(req, res, next) {
  const id = req.params.id;
  if (!/^[0-9]+$/.test(id)) {
    return res.status(400).json({ error: 'Invalid course ID' });
  }
  next();
}

// dynamic route with validation
router.get('/:id', validateCourseId, (req, res) => {
  const id = req.params.id;
  res.json({ id, name: 'React Mastery', duration: '6 weeks' });
});

module.exports = router;